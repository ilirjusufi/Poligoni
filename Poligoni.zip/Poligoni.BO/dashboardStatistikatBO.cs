﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poligoni.BO
{
   public class dashboardStatistikatBO
    {
        public  int klientateRegjistrua { get; set; }
        public int gjuajtjaTotale { get; set; }
        public int armeRegjisstruar { get; set; }
        public  int plumbaStok { get; set; }
    }
}
