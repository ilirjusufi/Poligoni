﻿namespace Poligoni
{
	partial class frmRegjistroGjuajtjen
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegjistroGjuajtjen));
            this.jGradientPanel1 = new JGradient_Panel.JGradientPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txtMaxPlumba = new System.Windows.Forms.TextBox();
            this.txtKalibri = new System.Windows.Forms.TextBox();
            this.btnRegjistroGjuajtjen = new FlatButton.JFlatButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblArma = new System.Windows.Forms.Label();
            this.jGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // jGradientPanel1
            // 
            this.jGradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.Controls.Add(this.label2);
            this.jGradientPanel1.Controls.Add(this.pictureBox5);
            this.jGradientPanel1.Controls.Add(this.pictureBox3);
            this.jGradientPanel1.Controls.Add(this.textBox1);
            this.jGradientPanel1.Controls.Add(this.label1);
            this.jGradientPanel1.Controls.Add(this.listBox1);
            this.jGradientPanel1.Controls.Add(this.pictureBox2);
            this.jGradientPanel1.Controls.Add(this.pictureBox1);
            this.jGradientPanel1.Controls.Add(this.pictureBox4);
            this.jGradientPanel1.Controls.Add(this.txtMaxPlumba);
            this.jGradientPanel1.Controls.Add(this.txtKalibri);
            this.jGradientPanel1.Controls.Add(this.btnRegjistroGjuajtjen);
            this.jGradientPanel1.Controls.Add(this.label4);
            this.jGradientPanel1.Controls.Add(this.label5);
            this.jGradientPanel1.Controls.Add(this.lblArma);
            this.jGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.jGradientPanel1.Name = "jGradientPanel1";
            this.jGradientPanel1.Size = new System.Drawing.Size(800, 450);
            this.jGradientPanel1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Montserrat", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(238, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(264, 33);
            this.label2.TabIndex = 26;
            this.label2.Text = "Regjistro Gjuajtjen\r\n";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(552, -30);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(236, 514);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 25;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(245, 228);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(28, 31);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 24;
            this.pictureBox3.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Montserrat", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(279, 228);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(254, 31);
            this.textBox1.TabIndex = 23;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(75, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 19);
            this.label1.TabIndex = 22;
            this.label1.Text = "Distanca e gjuajtjes";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.listBox1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.Color.White;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Items.AddRange(new object[] {
            "Glock",
            "M4a1"});
            this.listBox1.Location = new System.Drawing.Point(279, 111);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(254, 23);
            this.listBox1.TabIndex = 21;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(245, 110);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(245, 294);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(245, 169);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(28, 31);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // txtMaxPlumba
            // 
            this.txtMaxPlumba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtMaxPlumba.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMaxPlumba.Font = new System.Drawing.Font("Montserrat", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaxPlumba.ForeColor = System.Drawing.Color.White;
            this.txtMaxPlumba.Location = new System.Drawing.Point(279, 294);
            this.txtMaxPlumba.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtMaxPlumba.Multiline = true;
            this.txtMaxPlumba.Name = "txtMaxPlumba";
            this.txtMaxPlumba.Size = new System.Drawing.Size(254, 31);
            this.txtMaxPlumba.TabIndex = 16;
            this.txtMaxPlumba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtKalibri
            // 
            this.txtKalibri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtKalibri.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtKalibri.Font = new System.Drawing.Font("Montserrat", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKalibri.ForeColor = System.Drawing.Color.White;
            this.txtKalibri.Location = new System.Drawing.Point(279, 169);
            this.txtKalibri.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtKalibri.Multiline = true;
            this.txtKalibri.Name = "txtKalibri";
            this.txtKalibri.Size = new System.Drawing.Size(254, 31);
            this.txtKalibri.TabIndex = 15;
            this.txtKalibri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnRegjistroGjuajtjen
            // 
            this.btnRegjistroGjuajtjen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroGjuajtjen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroGjuajtjen.ButtonText = "Regjistro Gjuajtjen";
            this.btnRegjistroGjuajtjen.CausesValidation = false;
            this.btnRegjistroGjuajtjen.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroGjuajtjen.ErrorImageLeft")));
            this.btnRegjistroGjuajtjen.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btnRegjistroGjuajtjen.ErrorImageRight")));
            this.btnRegjistroGjuajtjen.FocusBackground = System.Drawing.Color.Empty;
            this.btnRegjistroGjuajtjen.FocusFontColor = System.Drawing.Color.Empty;
            this.btnRegjistroGjuajtjen.ForeColors = System.Drawing.Color.White;
            this.btnRegjistroGjuajtjen.HoverBackground = System.Drawing.Color.DarkSlateGray;
            this.btnRegjistroGjuajtjen.HoverFontColor = System.Drawing.Color.Transparent;
            this.btnRegjistroGjuajtjen.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroGjuajtjen.ImageLeft")));
            this.btnRegjistroGjuajtjen.ImageRight = null;
            this.btnRegjistroGjuajtjen.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroGjuajtjen.Location = new System.Drawing.Point(279, 364);
            this.btnRegjistroGjuajtjen.Name = "btnRegjistroGjuajtjen";
            this.btnRegjistroGjuajtjen.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroGjuajtjen.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroGjuajtjen.RightPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroGjuajtjen.Size = new System.Drawing.Size(254, 43);
            this.btnRegjistroGjuajtjen.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btnRegjistroGjuajtjen.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btnRegjistroGjuajtjen.TabIndex = 13;
            this.btnRegjistroGjuajtjen.Click += new System.EventHandler(this.btnRegjistroGjuajtjen_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(52, 303);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "Plumbat e shfrytezuar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(95, 178);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Piket e shenuara";
            // 
            // lblArma
            // 
            this.lblArma.AutoSize = true;
            this.lblArma.BackColor = System.Drawing.Color.Transparent;
            this.lblArma.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArma.ForeColor = System.Drawing.Color.White;
            this.lblArma.Location = new System.Drawing.Point(110, 119);
            this.lblArma.Name = "lblArma";
            this.lblArma.Size = new System.Drawing.Size(127, 19);
            this.lblArma.TabIndex = 8;
            this.lblArma.Text = "Selekto Armen";
            // 
            // frmRegjistroGjuajtjen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.jGradientPanel1);
            this.Name = "frmRegjistroGjuajtjen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmRegjistroGjuajtjen";
            this.jGradientPanel1.ResumeLayout(false);
            this.jGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private JGradient_Panel.JGradientPanel jGradientPanel1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.TextBox txtMaxPlumba;
		private System.Windows.Forms.TextBox txtKalibri;
		private FlatButton.JFlatButton btnRegjistroGjuajtjen;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lblArma;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
	}
}