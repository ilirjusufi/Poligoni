﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poligoni.BO
{
  public class gjuajtja
    {
        public string kalbri;
        public string distanca;
        public string maxplumba;
        public int arma;
    }
}
