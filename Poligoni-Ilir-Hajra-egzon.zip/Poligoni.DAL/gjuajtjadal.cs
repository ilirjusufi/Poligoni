﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Poligoni.BO;

namespace Poligoni.DAL
{
    class gjuajtjadal
    {
        gjuajtja ngarko = new gjuajtja();
        public gjuajtja RegjistroArmen()
        {

            using (var conn = DataConnection.GetConnection())
            {

                using (var cmd = DataConnection.Command(conn, "usp_Gjuajtja", CommandType.StoredProcedure))
                {

                    DataConnection.AddParameter(cmd, "@Aarmaid", ngarko.arma);
                    DataConnection.AddParameter(cmd, "@Distanca", ngarko.distanca);
                    DataConnection.AddParameter(cmd, "@pshenuara", ngarko.kalbri);
                    DataConnection.AddParameter(cmd, "@plumbashfryzuar", ngarko.maxplumba);
                    DataConnection.AddParameter(cmd, "@insertby", UserSession1.CurrentUser.ID);
                    cmd.ExecuteNonQuery();
                    return null;
                }
            }
        }
    }
}
