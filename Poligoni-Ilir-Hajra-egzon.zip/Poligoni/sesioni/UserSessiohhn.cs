﻿using Poligoni.BO;
using System;
using Poligoni.DAL;

namespace Poligoni
{
    public class UserSession
    {
        public static Users CurrentUser = null;   
    }
    
}