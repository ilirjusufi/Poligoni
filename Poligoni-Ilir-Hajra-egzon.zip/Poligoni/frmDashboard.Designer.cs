﻿namespace Poligoni
{
    partial class FrmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDashboard));
            this.panel4 = new System.Windows.Forms.Panel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnRegjistroGjuajtje = new Guna.UI2.WinForms.Guna2Button();
            this.btnregjistroplumba = new Guna.UI2.WinForms.Guna2Button();
            this.btnregjistoklienta = new Guna.UI2.WinForms.Guna2Button();
            this.btnregjistroarm = new Guna.UI2.WinForms.Guna2Button();
            this.lblemrimbiemri = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.jGradientPanel1 = new JGradient_Panel.JGradientPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.financatrrethi = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar2 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label14 = new System.Windows.Forms.Label();
            this.lblfinancat = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar3 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label12 = new System.Windows.Forms.Label();
            this.lblaremtregjistruar = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar5 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label13 = new System.Windows.Forms.Label();
            this.lblplumbastok = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblklientaregjistrum = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2CircleProgressBar1 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar4 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label11 = new System.Windows.Forms.Label();
            this.lblgjuajtjet = new System.Windows.Forms.Label();
            this.lbldata = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblemri = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.administrimiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroStafToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ndyshoStafToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.klientatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroKlientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listoKlientToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.armetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menaxhoArmetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.plumbatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroPlumbaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menaxhoPlumbatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gjuajtjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroGjuajtjenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listoTeGjithaGjuajtjetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raportetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.jGradientPanel1.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel4.Controls.Add(this.guna2Button1);
            this.panel4.Controls.Add(this.btnRegjistroGjuajtje);
            this.panel4.Controls.Add(this.btnregjistroplumba);
            this.panel4.Controls.Add(this.btnregjistoklienta);
            this.panel4.Controls.Add(this.btnregjistroarm);
            this.panel4.Controls.Add(this.lblemrimbiemri);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Location = new System.Drawing.Point(3, 29);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(209, 715);
            this.panel4.TabIndex = 2;
            // 
            // guna2Button1
            // 
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(0, 598);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(51, 29);
            this.guna2Button1.TabIndex = 6;
            this.guna2Button1.Text = "Qkyqu";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // btnRegjistroGjuajtje
            // 
            this.btnRegjistroGjuajtje.CheckedState.Parent = this.btnRegjistroGjuajtje;
            this.btnRegjistroGjuajtje.CustomImages.Parent = this.btnRegjistroGjuajtje;
            this.btnRegjistroGjuajtje.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.btnRegjistroGjuajtje.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegjistroGjuajtje.ForeColor = System.Drawing.Color.White;
            this.btnRegjistroGjuajtje.HoverState.Parent = this.btnRegjistroGjuajtje;
            this.btnRegjistroGjuajtje.Location = new System.Drawing.Point(13, 288);
            this.btnRegjistroGjuajtje.Name = "btnRegjistroGjuajtje";
            this.btnRegjistroGjuajtje.ShadowDecoration.Parent = this.btnRegjistroGjuajtje;
            this.btnRegjistroGjuajtje.Size = new System.Drawing.Size(180, 45);
            this.btnRegjistroGjuajtje.TabIndex = 4;
            this.btnRegjistroGjuajtje.Text = "Regjistro gjuajtje";
            this.btnRegjistroGjuajtje.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRegjistroGjuajtje.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.btnRegjistroGjuajtje.Click += new System.EventHandler(this.btnRegjistroGjuajtje_Click);
            // 
            // btnregjistroplumba
            // 
            this.btnregjistroplumba.CheckedState.Parent = this.btnregjistroplumba;
            this.btnregjistroplumba.CustomImages.Parent = this.btnregjistroplumba;
            this.btnregjistroplumba.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.btnregjistroplumba.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregjistroplumba.ForeColor = System.Drawing.Color.White;
            this.btnregjistroplumba.HoverState.Parent = this.btnregjistroplumba;
            this.btnregjistroplumba.Location = new System.Drawing.Point(13, 441);
            this.btnregjistroplumba.Name = "btnregjistroplumba";
            this.btnregjistroplumba.ShadowDecoration.Parent = this.btnregjistroplumba;
            this.btnregjistroplumba.Size = new System.Drawing.Size(180, 45);
            this.btnregjistroplumba.TabIndex = 3;
            this.btnregjistroplumba.Text = "Regjistro plumba";
            this.btnregjistroplumba.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnregjistroplumba.Click += new System.EventHandler(this.btnregjistroplumba_Click);
            // 
            // btnregjistoklienta
            // 
            this.btnregjistoklienta.CheckedState.Parent = this.btnregjistoklienta;
            this.btnregjistoklienta.CustomImages.Parent = this.btnregjistoklienta;
            this.btnregjistoklienta.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.btnregjistoklienta.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregjistoklienta.ForeColor = System.Drawing.Color.White;
            this.btnregjistoklienta.HoverState.Parent = this.btnregjistoklienta;
            this.btnregjistoklienta.Location = new System.Drawing.Point(13, 339);
            this.btnregjistoklienta.Name = "btnregjistoklienta";
            this.btnregjistoklienta.ShadowDecoration.Parent = this.btnregjistoklienta;
            this.btnregjistoklienta.Size = new System.Drawing.Size(180, 45);
            this.btnregjistoklienta.TabIndex = 3;
            this.btnregjistoklienta.Text = "Regjistro klienta";
            this.btnregjistoklienta.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnregjistoklienta.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.btnregjistoklienta.Click += new System.EventHandler(this.btnregjistoklienta_Click);
            // 
            // btnregjistroarm
            // 
            this.btnregjistroarm.CheckedState.Parent = this.btnregjistroarm;
            this.btnregjistroarm.CustomImages.Parent = this.btnregjistroarm;
            this.btnregjistroarm.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.btnregjistroarm.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregjistroarm.ForeColor = System.Drawing.Color.White;
            this.btnregjistroarm.HoverState.Parent = this.btnregjistroarm;
            this.btnregjistroarm.Location = new System.Drawing.Point(13, 390);
            this.btnregjistroarm.Name = "btnregjistroarm";
            this.btnregjistroarm.ShadowDecoration.Parent = this.btnregjistroarm;
            this.btnregjistroarm.Size = new System.Drawing.Size(180, 45);
            this.btnregjistroarm.TabIndex = 2;
            this.btnregjistroarm.Text = "Regjistro arme";
            this.btnregjistroarm.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnregjistroarm.Click += new System.EventHandler(this.btnregjistroarm_Click);
            // 
            // lblemrimbiemri
            // 
            this.lblemrimbiemri.AutoSize = true;
            this.lblemrimbiemri.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemrimbiemri.ForeColor = System.Drawing.Color.LightGray;
            this.lblemrimbiemri.Location = new System.Drawing.Point(70, 195);
            this.lblemrimbiemri.Name = "lblemrimbiemri";
            this.lblemrimbiemri.Size = new System.Drawing.Size(0, 24);
            this.lblemrimbiemri.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.LightGray;
            this.label5.Location = new System.Drawing.Point(62, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 24);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mr.Msc";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.LightGray;
            this.label2.Location = new System.Drawing.Point(30, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Paneli i kontrollit";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Poligoni.Properties.Resources._20;
            this.pictureBox1.Location = new System.Drawing.Point(38, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(127, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // jGradientPanel1
            // 
            this.jGradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorBottom = System.Drawing.Color.Empty;
            this.jGradientPanel1.ColorTop = System.Drawing.Color.Empty;
            this.jGradientPanel1.Controls.Add(this.panel12);
            this.jGradientPanel1.Controls.Add(this.panel7);
            this.jGradientPanel1.Controls.Add(this.label3);
            this.jGradientPanel1.Controls.Add(this.panel6);
            this.jGradientPanel1.Controls.Add(this.lbldata);
            this.jGradientPanel1.Controls.Add(this.label18);
            this.jGradientPanel1.Controls.Add(this.lblemri);
            this.jGradientPanel1.Controls.Add(this.label1);
            this.jGradientPanel1.Controls.Add(this.menuStrip1);
            this.jGradientPanel1.Controls.Add(this.panel4);
            this.jGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.jGradientPanel1.Name = "jGradientPanel1";
            this.jGradientPanel1.Size = new System.Drawing.Size(1210, 659);
            this.jGradientPanel1.TabIndex = 0;
            this.jGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.jGradientPanel1_Paint);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel12.Controls.Add(this.panel13);
            this.panel12.Controls.Add(this.financatrrethi);
            this.panel12.Controls.Add(this.label15);
            this.panel12.Controls.Add(this.label16);
            this.panel12.Controls.Add(this.label17);
            this.panel12.Location = new System.Drawing.Point(739, 256);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(446, 383);
            this.panel12.TabIndex = 4;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(179)))), ((int)(((byte)(133)))));
            this.panel13.Location = new System.Drawing.Point(20, 64);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(10, 258);
            this.panel13.TabIndex = 8;
            // 
            // financatrrethi
            // 
            this.financatrrethi.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.financatrrethi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.financatrrethi.Location = new System.Drawing.Point(76, 49);
            this.financatrrethi.Name = "financatrrethi";
            this.financatrrethi.ProgressColor = System.Drawing.Color.White;
            this.financatrrethi.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.financatrrethi.ShadowDecoration.Parent = this.financatrrethi;
            this.financatrrethi.ShowPercentage = true;
            this.financatrrethi.Size = new System.Drawing.Size(294, 282);
            this.financatrrethi.TabIndex = 6;
            this.financatrrethi.Value = 30;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.LightGray;
            this.label15.Location = new System.Drawing.Point(16, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(127, 24);
            this.label15.TabIndex = 1;
            this.label15.Text = "Te hyrat totale";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.LightGray;
            this.label16.Location = new System.Drawing.Point(199, 349);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 24);
            this.label16.TabIndex = 1;
            this.label16.Text = "00000";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.LightGray;
            this.label17.Location = new System.Drawing.Point(16, 348);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 24);
            this.label17.TabIndex = 1;
            this.label17.Text = "Total te hyrat:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel7.Controls.Add(this.panel14);
            this.panel7.Controls.Add(this.guna2CircleProgressBar2);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.lblfinancat);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Location = new System.Drawing.Point(243, 256);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(446, 383);
            this.panel7.TabIndex = 4;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(152)))), ((int)(((byte)(50)))));
            this.panel14.Location = new System.Drawing.Point(18, 73);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(10, 258);
            this.panel14.TabIndex = 8;
            // 
            // guna2CircleProgressBar2
            // 
            this.guna2CircleProgressBar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2CircleProgressBar2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.guna2CircleProgressBar2.Location = new System.Drawing.Point(76, 49);
            this.guna2CircleProgressBar2.Name = "guna2CircleProgressBar2";
            this.guna2CircleProgressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(112)))), ((int)(((byte)(94)))));
            this.guna2CircleProgressBar2.ProgressColor2 = System.Drawing.Color.Olive;
            this.guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar2.ShadowDecoration.Parent = this.guna2CircleProgressBar2;
            this.guna2CircleProgressBar2.ShowPercentage = true;
            this.guna2CircleProgressBar2.Size = new System.Drawing.Size(294, 282);
            this.guna2CircleProgressBar2.TabIndex = 6;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.LightGray;
            this.label14.Location = new System.Drawing.Point(16, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(240, 24);
            this.label14.TabIndex = 1;
            this.label14.Text = "Të hyrat totale në ketë muaj";
            // 
            // lblfinancat
            // 
            this.lblfinancat.AutoSize = true;
            this.lblfinancat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfinancat.ForeColor = System.Drawing.Color.LightGray;
            this.lblfinancat.Location = new System.Drawing.Point(199, 349);
            this.lblfinancat.Name = "lblfinancat";
            this.lblfinancat.Size = new System.Drawing.Size(60, 24);
            this.lblfinancat.TabIndex = 1;
            this.lblfinancat.Text = "00000";
            this.lblfinancat.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblfinancat.Click += new System.EventHandler(this.lblfinancat_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.LightGray;
            this.label4.Location = new System.Drawing.Point(16, 348);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 24);
            this.label4.TabIndex = 1;
            this.label4.Text = "Total te hyrat:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.LightGray;
            this.label3.Location = new System.Drawing.Point(302, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 24);
            this.label3.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.panel3);
            this.panel6.Controls.Add(this.panel5);
            this.panel6.Controls.Add(this.panel1);
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Location = new System.Drawing.Point(229, 74);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1007, 142);
            this.panel6.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.guna2CircleProgressBar3);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.lblaremtregjistruar);
            this.panel3.Location = new System.Drawing.Point(510, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 114);
            this.panel3.TabIndex = 4;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(136)))), ((int)(((byte)(114)))));
            this.panel10.Location = new System.Drawing.Point(16, 29);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(3, 65);
            this.panel10.TabIndex = 8;
            // 
            // guna2CircleProgressBar3
            // 
            this.guna2CircleProgressBar3.FillThickness = 5;
            this.guna2CircleProgressBar3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.guna2CircleProgressBar3.Location = new System.Drawing.Point(133, 37);
            this.guna2CircleProgressBar3.Name = "guna2CircleProgressBar3";
            this.guna2CircleProgressBar3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.guna2CircleProgressBar3.ProgressThickness = 5;
            this.guna2CircleProgressBar3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar3.ShadowDecoration.Parent = this.guna2CircleProgressBar3;
            this.guna2CircleProgressBar3.ShowPercentage = true;
            this.guna2CircleProgressBar3.Size = new System.Drawing.Size(57, 56);
            this.guna2CircleProgressBar3.TabIndex = 0;
            this.guna2CircleProgressBar3.Value = 30;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F);
            this.label12.ForeColor = System.Drawing.Color.LightGray;
            this.label12.Location = new System.Drawing.Point(9, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(124, 16);
            this.label12.TabIndex = 1;
            this.label12.Text = "Arme të regjistruara";
            // 
            // lblaremtregjistruar
            // 
            this.lblaremtregjistruar.AutoSize = true;
            this.lblaremtregjistruar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaremtregjistruar.ForeColor = System.Drawing.Color.LightGray;
            this.lblaremtregjistruar.Location = new System.Drawing.Point(34, 50);
            this.lblaremtregjistruar.Name = "lblaremtregjistruar";
            this.lblaremtregjistruar.Size = new System.Drawing.Size(50, 24);
            this.lblaremtregjistruar.TabIndex = 7;
            this.lblaremtregjistruar.Text = "0000";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel5.Controls.Add(this.panel11);
            this.panel5.Controls.Add(this.guna2CircleProgressBar5);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.lblplumbastok);
            this.panel5.Location = new System.Drawing.Point(756, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 114);
            this.panel5.TabIndex = 4;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(179)))), ((int)(((byte)(133)))));
            this.panel11.Location = new System.Drawing.Point(17, 29);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(3, 65);
            this.panel11.TabIndex = 8;
            // 
            // guna2CircleProgressBar5
            // 
            this.guna2CircleProgressBar5.FillThickness = 5;
            this.guna2CircleProgressBar5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.guna2CircleProgressBar5.Location = new System.Drawing.Point(131, 37);
            this.guna2CircleProgressBar5.Name = "guna2CircleProgressBar5";
            this.guna2CircleProgressBar5.ProgressColor = System.Drawing.Color.White;
            this.guna2CircleProgressBar5.ProgressThickness = 5;
            this.guna2CircleProgressBar5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar5.ShadowDecoration.Parent = this.guna2CircleProgressBar5;
            this.guna2CircleProgressBar5.ShowPercentage = true;
            this.guna2CircleProgressBar5.Size = new System.Drawing.Size(57, 56);
            this.guna2CircleProgressBar5.TabIndex = 1;
            this.guna2CircleProgressBar5.Value = 30;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F);
            this.label13.ForeColor = System.Drawing.Color.LightGray;
            this.label13.Location = new System.Drawing.Point(10, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 16);
            this.label13.TabIndex = 1;
            this.label13.Text = "Plumba ne stok";
            // 
            // lblplumbastok
            // 
            this.lblplumbastok.AutoSize = true;
            this.lblplumbastok.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblplumbastok.ForeColor = System.Drawing.Color.LightGray;
            this.lblplumbastok.Location = new System.Drawing.Point(35, 50);
            this.lblplumbastok.Name = "lblplumbastok";
            this.lblplumbastok.Size = new System.Drawing.Size(50, 24);
            this.lblplumbastok.TabIndex = 7;
            this.lblplumbastok.Text = "0000";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.lblklientaregjistrum);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.guna2CircleProgressBar1);
            this.panel1.Location = new System.Drawing.Point(14, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 114);
            this.panel1.TabIndex = 4;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(179)))), ((int)(((byte)(133)))));
            this.panel8.Location = new System.Drawing.Point(20, 29);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(3, 65);
            this.panel8.TabIndex = 6;
            // 
            // lblklientaregjistrum
            // 
            this.lblklientaregjistrum.AutoSize = true;
            this.lblklientaregjistrum.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblklientaregjistrum.ForeColor = System.Drawing.Color.LightGray;
            this.lblklientaregjistrum.Location = new System.Drawing.Point(38, 50);
            this.lblklientaregjistrum.Name = "lblklientaregjistrum";
            this.lblklientaregjistrum.Size = new System.Drawing.Size(50, 24);
            this.lblklientaregjistrum.TabIndex = 1;
            this.lblklientaregjistrum.Text = "0000";
            this.lblklientaregjistrum.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.LightGray;
            this.label6.Location = new System.Drawing.Point(11, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Klienta të regjistruar";
            // 
            // guna2CircleProgressBar1
            // 
            this.guna2CircleProgressBar1.FillThickness = 5;
            this.guna2CircleProgressBar1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.guna2CircleProgressBar1.Location = new System.Drawing.Point(136, 37);
            this.guna2CircleProgressBar1.Name = "guna2CircleProgressBar1";
            this.guna2CircleProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.guna2CircleProgressBar1.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(174)))), ((int)(((byte)(182)))));
            this.guna2CircleProgressBar1.ProgressThickness = 5;
            this.guna2CircleProgressBar1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar1.ShadowDecoration.Parent = this.guna2CircleProgressBar1;
            this.guna2CircleProgressBar1.ShowPercentage = true;
            this.guna2CircleProgressBar1.Size = new System.Drawing.Size(57, 56);
            this.guna2CircleProgressBar1.TabIndex = 0;
            this.guna2CircleProgressBar1.Value = 30;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.guna2CircleProgressBar4);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.lblgjuajtjet);
            this.panel2.Location = new System.Drawing.Point(260, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 114);
            this.panel2.TabIndex = 4;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(152)))), ((int)(((byte)(50)))));
            this.panel9.Location = new System.Drawing.Point(17, 29);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(3, 65);
            this.panel9.TabIndex = 8;
            // 
            // guna2CircleProgressBar4
            // 
            this.guna2CircleProgressBar4.FillThickness = 5;
            this.guna2CircleProgressBar4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.guna2CircleProgressBar4.Location = new System.Drawing.Point(134, 37);
            this.guna2CircleProgressBar4.Name = "guna2CircleProgressBar4";
            this.guna2CircleProgressBar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2CircleProgressBar4.ProgressThickness = 5;
            this.guna2CircleProgressBar4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar4.ShadowDecoration.Parent = this.guna2CircleProgressBar4;
            this.guna2CircleProgressBar4.ShowPercentage = true;
            this.guna2CircleProgressBar4.Size = new System.Drawing.Size(57, 56);
            this.guna2CircleProgressBar4.TabIndex = 0;
            this.guna2CircleProgressBar4.Value = 30;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F);
            this.label11.ForeColor = System.Drawing.Color.LightGray;
            this.label11.Location = new System.Drawing.Point(10, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 16);
            this.label11.TabIndex = 1;
            this.label11.Text = "Gjuajtje totale";
            // 
            // lblgjuajtjet
            // 
            this.lblgjuajtjet.AutoSize = true;
            this.lblgjuajtjet.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgjuajtjet.ForeColor = System.Drawing.Color.LightGray;
            this.lblgjuajtjet.Location = new System.Drawing.Point(35, 50);
            this.lblgjuajtjet.Name = "lblgjuajtjet";
            this.lblgjuajtjet.Size = new System.Drawing.Size(50, 24);
            this.lblgjuajtjet.TabIndex = 7;
            this.lblgjuajtjet.Text = "0000";
            // 
            // lbldata
            // 
            this.lbldata.AutoSize = true;
            this.lbldata.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldata.ForeColor = System.Drawing.Color.LightGray;
            this.lbldata.Location = new System.Drawing.Point(967, 35);
            this.lbldata.Name = "lbldata";
            this.lbldata.Size = new System.Drawing.Size(47, 24);
            this.lbldata.TabIndex = 1;
            this.lbldata.Text = "Data";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.LightGray;
            this.label18.Location = new System.Drawing.Point(834, 34);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(136, 24);
            this.label18.TabIndex = 1;
            this.label18.Text = "Data dhe koha:";
            // 
            // lblemri
            // 
            this.lblemri.AutoSize = true;
            this.lblemri.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemri.ForeColor = System.Drawing.Color.LightGray;
            this.lblemri.Location = new System.Drawing.Point(384, 36);
            this.lblemri.Name = "lblemri";
            this.lblemri.Size = new System.Drawing.Size(66, 24);
            this.lblemri.TabIndex = 1;
            this.lblemri.Text = "lblemri";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(239, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pershendetje";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(13)))), ((int)(((byte)(32)))));
            this.menuStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.administrimiToolStripMenuItem,
            this.klientatToolStripMenuItem,
            this.armetToolStripMenuItem,
            this.plumbatToolStripMenuItem,
            this.gjuajtjaToolStripMenuItem,
            this.raportetToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1210, 25);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked_1);
            // 
            // administrimiToolStripMenuItem
            // 
            this.administrimiToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.administrimiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroStafToolStripMenuItem,
            this.ndyshoStafToolStripMenuItem});
            this.administrimiToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.administrimiToolStripMenuItem.Name = "administrimiToolStripMenuItem";
            this.administrimiToolStripMenuItem.Size = new System.Drawing.Size(95, 21);
            this.administrimiToolStripMenuItem.Text = "Administrimi";
            // 
            // regjistroStafToolStripMenuItem
            // 
            this.regjistroStafToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("regjistroStafToolStripMenuItem.Image")));
            this.regjistroStafToolStripMenuItem.Name = "regjistroStafToolStripMenuItem";
            this.regjistroStafToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.regjistroStafToolStripMenuItem.Text = "Regjistro Staf";
            this.regjistroStafToolStripMenuItem.Click += new System.EventHandler(this.regjistroStafToolStripMenuItem_Click);
            // 
            // ndyshoStafToolStripMenuItem
            // 
            this.ndyshoStafToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ndyshoStafToolStripMenuItem.Image")));
            this.ndyshoStafToolStripMenuItem.Name = "ndyshoStafToolStripMenuItem";
            this.ndyshoStafToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ndyshoStafToolStripMenuItem.Text = "Ndysho Staf";
            this.ndyshoStafToolStripMenuItem.Click += new System.EventHandler(this.ndyshoStafToolStripMenuItem_Click);
            // 
            // klientatToolStripMenuItem
            // 
            this.klientatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroKlientToolStripMenuItem,
            this.listoKlientToolStripMenuItem1});
            this.klientatToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.klientatToolStripMenuItem.Name = "klientatToolStripMenuItem";
            this.klientatToolStripMenuItem.Size = new System.Drawing.Size(67, 21);
            this.klientatToolStripMenuItem.Text = "Klientat";
            // 
            // regjistroKlientToolStripMenuItem
            // 
            this.regjistroKlientToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("regjistroKlientToolStripMenuItem.Image")));
            this.regjistroKlientToolStripMenuItem.Name = "regjistroKlientToolStripMenuItem";
            this.regjistroKlientToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.regjistroKlientToolStripMenuItem.Text = "Regjistro Klient";
            this.regjistroKlientToolStripMenuItem.Click += new System.EventHandler(this.regjistroKlientToolStripMenuItem_Click_4);
            // 
            // listoKlientToolStripMenuItem1
            // 
            this.listoKlientToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("listoKlientToolStripMenuItem1.Image")));
            this.listoKlientToolStripMenuItem1.Name = "listoKlientToolStripMenuItem1";
            this.listoKlientToolStripMenuItem1.Size = new System.Drawing.Size(184, 22);
            this.listoKlientToolStripMenuItem1.Text = "Menaxho Klientat";
            this.listoKlientToolStripMenuItem1.Click += new System.EventHandler(this.listoKlientToolStripMenuItem1_Click);
            // 
            // armetToolStripMenuItem
            // 
            this.armetToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroToolStripMenuItem,
            this.menaxhoArmetToolStripMenuItem});
            this.armetToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.armetToolStripMenuItem.Name = "armetToolStripMenuItem";
            this.armetToolStripMenuItem.Size = new System.Drawing.Size(57, 21);
            this.armetToolStripMenuItem.Text = "Armet";
            // 
            // regjistroToolStripMenuItem
            // 
            this.regjistroToolStripMenuItem.Image = global::Poligoni.Properties.Resources.gun;
            this.regjistroToolStripMenuItem.Name = "regjistroToolStripMenuItem";
            this.regjistroToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.regjistroToolStripMenuItem.Text = "Regjistro Armë";
            this.regjistroToolStripMenuItem.Click += new System.EventHandler(this.regjistroToolStripMenuItem_Click);
            // 
            // menaxhoArmetToolStripMenuItem
            // 
            this.menaxhoArmetToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("menaxhoArmetToolStripMenuItem.Image")));
            this.menaxhoArmetToolStripMenuItem.Name = "menaxhoArmetToolStripMenuItem";
            this.menaxhoArmetToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menaxhoArmetToolStripMenuItem.Text = "Menaxho Armet";
            this.menaxhoArmetToolStripMenuItem.Click += new System.EventHandler(this.menaxhoArmetToolStripMenuItem_Click);
            // 
            // plumbatToolStripMenuItem
            // 
            this.plumbatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroPlumbaToolStripMenuItem,
            this.menaxhoPlumbatToolStripMenuItem});
            this.plumbatToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.plumbatToolStripMenuItem.Name = "plumbatToolStripMenuItem";
            this.plumbatToolStripMenuItem.Size = new System.Drawing.Size(71, 21);
            this.plumbatToolStripMenuItem.Text = "Plumbat";
            // 
            // regjistroPlumbaToolStripMenuItem
            // 
            this.regjistroPlumbaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("regjistroPlumbaToolStripMenuItem.Image")));
            this.regjistroPlumbaToolStripMenuItem.Name = "regjistroPlumbaToolStripMenuItem";
            this.regjistroPlumbaToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.regjistroPlumbaToolStripMenuItem.Text = "Regjistro Plumba";
            this.regjistroPlumbaToolStripMenuItem.Click += new System.EventHandler(this.regjistroPlumbaToolStripMenuItem_Click);
            // 
            // menaxhoPlumbatToolStripMenuItem
            // 
            this.menaxhoPlumbatToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("menaxhoPlumbatToolStripMenuItem.Image")));
            this.menaxhoPlumbatToolStripMenuItem.Name = "menaxhoPlumbatToolStripMenuItem";
            this.menaxhoPlumbatToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.menaxhoPlumbatToolStripMenuItem.Text = "Menaxho Plumbat";
            this.menaxhoPlumbatToolStripMenuItem.Click += new System.EventHandler(this.menaxhoPlumbatToolStripMenuItem_Click);
            // 
            // gjuajtjaToolStripMenuItem
            // 
            this.gjuajtjaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroGjuajtjenToolStripMenuItem,
            this.listoTeGjithaGjuajtjetToolStripMenuItem});
            this.gjuajtjaToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.gjuajtjaToolStripMenuItem.Name = "gjuajtjaToolStripMenuItem";
            this.gjuajtjaToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.gjuajtjaToolStripMenuItem.Text = "Gjuajtja";
            // 
            // regjistroGjuajtjenToolStripMenuItem
            // 
            this.regjistroGjuajtjenToolStripMenuItem.Image = global::Poligoni.Properties.Resources._4;
            this.regjistroGjuajtjenToolStripMenuItem.Name = "regjistroGjuajtjenToolStripMenuItem";
            this.regjistroGjuajtjenToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.regjistroGjuajtjenToolStripMenuItem.Text = "Regjistro gjuajtjen";
            this.regjistroGjuajtjenToolStripMenuItem.Click += new System.EventHandler(this.regjistroGjuajtjenToolStripMenuItem_Click);
            // 
            // listoTeGjithaGjuajtjetToolStripMenuItem
            // 
            this.listoTeGjithaGjuajtjetToolStripMenuItem.Name = "listoTeGjithaGjuajtjetToolStripMenuItem";
            this.listoTeGjithaGjuajtjetToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.listoTeGjithaGjuajtjetToolStripMenuItem.Text = "Menagjo gjuajtjen";
            this.listoTeGjithaGjuajtjetToolStripMenuItem.Click += new System.EventHandler(this.listoTeGjithaGjuajtjetToolStripMenuItem_Click);
            // 
            // raportetToolStripMenuItem
            // 
            this.raportetToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.raportetToolStripMenuItem.Name = "raportetToolStripMenuItem";
            this.raportetToolStripMenuItem.Size = new System.Drawing.Size(75, 21);
            this.raportetToolStripMenuItem.Text = "Raportet";
            this.raportetToolStripMenuItem.Click += new System.EventHandler(this.raportetToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FrmDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1210, 659);
            this.Controls.Add(this.jGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FrmDashboard";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.FrmDashboard_Load_1);
            this.Shown += new System.EventHandler(this.FrmDashboard_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.jGradientPanel1.ResumeLayout(false);
            this.jGradientPanel1.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblemrimbiemri;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private JGradient_Panel.JGradientPanel jGradientPanel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar4;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar3;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar5;
        private System.Windows.Forms.Panel panel8;
        private Guna.UI2.WinForms.Guna2Button btnregjistroarm;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblfinancat;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblaremtregjistruar;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblplumbastok;
        private System.Windows.Forms.Label lblklientaregjistrum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblgjuajtjet;
        private Guna.UI2.WinForms.Guna2Button btnregjistroplumba;
        private Guna.UI2.WinForms.Guna2Button btnregjistoklienta;
        private System.Windows.Forms.Panel panel12;
        private Guna.UI2.WinForms.Guna2CircleProgressBar financatrrethi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbldata;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem administrimiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regjistroStafToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ndyshoStafToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem klientatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regjistroKlientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listoKlientToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem raportetToolStripMenuItem;
        private System.Windows.Forms.Label lblemri;
		private Guna.UI2.WinForms.Guna2Button btnRegjistroGjuajtje;
		private System.Windows.Forms.ToolStripMenuItem gjuajtjaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem regjistroGjuajtjenToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem listoTeGjithaGjuajtjetToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.ToolStripMenuItem armetToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem regjistroToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem menaxhoArmetToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem plumbatToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem regjistroPlumbaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem menaxhoPlumbatToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}