﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poligoni.BO
{
    public class UserSession1
    {
        public static Users CurrentUser = null;
        public static dashboardStatistikatBO merr = null;
    }
}
