﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poligoni.BO
{
  public class gjuajtja
    {
        public int  PiketEshenuara { get; set; }
        public string distanca { get; set; }
        public string plumbashfryzuar { get; set; }
        public string klienti { get; set; }
        public string Arma { get; set; }
    }
}
