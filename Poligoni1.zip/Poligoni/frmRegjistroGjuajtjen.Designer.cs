﻿namespace Poligoni
{
	partial class frmRegjistroGjuajtjen
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegjistroGjuajtjen));
            this.jGradientPanel1 = new JGradient_Panel.JGradientPanel();
            this.dropklientat = new System.Windows.Forms.ComboBox();
            this.useratBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dB_A62C25_poligoniDataSet2 = new Poligoni.DB_A62C25_poligoniDataSet2();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.droparmet = new System.Windows.Forms.ComboBox();
            this.armaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dB_A62C25_poligoniDataSet = new Poligoni.DB_A62C25_poligoniDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Txtdistanca = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txtMaxPlumba = new System.Windows.Forms.TextBox();
            this.txtKalibri = new System.Windows.Forms.TextBox();
            this.btnRegjistroGjuajtjen = new FlatButton.JFlatButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblArma = new System.Windows.Forms.Label();
            this.armaTableAdapter = new Poligoni.DB_A62C25_poligoniDataSetTableAdapters.ArmaTableAdapter();
            this.useratBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.useratTableAdapter1 = new Poligoni.DB_A62C25_poligoniDataSet2TableAdapters.UseratTableAdapter();
            this.btneditogjujtjen = new FlatButton.JFlatButton();
            this.jGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.useratBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_A62C25_poligoniDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_A62C25_poligoniDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.useratBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // jGradientPanel1
            // 
            this.jGradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.Controls.Add(this.btneditogjujtjen);
            this.jGradientPanel1.Controls.Add(this.dropklientat);
            this.jGradientPanel1.Controls.Add(this.pictureBox6);
            this.jGradientPanel1.Controls.Add(this.droparmet);
            this.jGradientPanel1.Controls.Add(this.label2);
            this.jGradientPanel1.Controls.Add(this.pictureBox5);
            this.jGradientPanel1.Controls.Add(this.pictureBox3);
            this.jGradientPanel1.Controls.Add(this.Txtdistanca);
            this.jGradientPanel1.Controls.Add(this.label1);
            this.jGradientPanel1.Controls.Add(this.pictureBox2);
            this.jGradientPanel1.Controls.Add(this.pictureBox1);
            this.jGradientPanel1.Controls.Add(this.pictureBox4);
            this.jGradientPanel1.Controls.Add(this.txtMaxPlumba);
            this.jGradientPanel1.Controls.Add(this.txtKalibri);
            this.jGradientPanel1.Controls.Add(this.btnRegjistroGjuajtjen);
            this.jGradientPanel1.Controls.Add(this.label4);
            this.jGradientPanel1.Controls.Add(this.label5);
            this.jGradientPanel1.Controls.Add(this.label3);
            this.jGradientPanel1.Controls.Add(this.lblArma);
            this.jGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.jGradientPanel1.Name = "jGradientPanel1";
            this.jGradientPanel1.Size = new System.Drawing.Size(792, 450);
            this.jGradientPanel1.TabIndex = 8;
            this.jGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.jGradientPanel1_Paint);
            // 
            // dropklientat
            // 
            this.dropklientat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.dropklientat.DataSource = this.useratBindingSource1;
            this.dropklientat.DisplayMember = "Username";
            this.dropklientat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dropklientat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dropklientat.ForeColor = System.Drawing.SystemColors.Info;
            this.dropklientat.FormattingEnabled = true;
            this.dropklientat.Location = new System.Drawing.Point(287, 84);
            this.dropklientat.Name = "dropklientat";
            this.dropklientat.Size = new System.Drawing.Size(248, 21);
            this.dropklientat.TabIndex = 39;
            this.dropklientat.ValueMember = "Username";
            // 
            // useratBindingSource1
            // 
            this.useratBindingSource1.DataMember = "Userat";
            this.useratBindingSource1.DataSource = this.dB_A62C25_poligoniDataSet2;
            // 
            // dB_A62C25_poligoniDataSet2
            // 
            this.dB_A62C25_poligoniDataSet2.DataSetName = "DB_A62C25_poligoniDataSet2";
            this.dB_A62C25_poligoniDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = global::Poligoni.Properties.Resources._3;
            this.pictureBox6.Location = new System.Drawing.Point(245, 81);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(31, 32);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 38;
            this.pictureBox6.TabStop = false;
            // 
            // droparmet
            // 
            this.droparmet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.droparmet.DataSource = this.armaBindingSource;
            this.droparmet.DisplayMember = "EmriArmes";
            this.droparmet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.droparmet.ForeColor = System.Drawing.SystemColors.Info;
            this.droparmet.FormattingEnabled = true;
            this.droparmet.Location = new System.Drawing.Point(283, 138);
            this.droparmet.Name = "droparmet";
            this.droparmet.Size = new System.Drawing.Size(254, 21);
            this.droparmet.TabIndex = 27;
            this.droparmet.ValueMember = "EmriArmes";
            // 
            // armaBindingSource
            // 
            this.armaBindingSource.DataMember = "Arma";
            this.armaBindingSource.DataSource = this.dB_A62C25_poligoniDataSet;
            // 
            // dB_A62C25_poligoniDataSet
            // 
            this.dB_A62C25_poligoniDataSet.DataSetName = "DB_A62C25_poligoniDataSet";
            this.dB_A62C25_poligoniDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(241, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(236, 31);
            this.label2.TabIndex = 26;
            this.label2.Text = "Regjistro Gjuajtjen\r\n";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(552, -28);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(236, 501);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 25;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(247, 248);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(28, 31);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 24;
            this.pictureBox3.TabStop = false;
            // 
            // Txtdistanca
            // 
            this.Txtdistanca.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.Txtdistanca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txtdistanca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txtdistanca.ForeColor = System.Drawing.Color.White;
            this.Txtdistanca.Location = new System.Drawing.Point(281, 248);
            this.Txtdistanca.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.Txtdistanca.Multiline = true;
            this.Txtdistanca.Name = "Txtdistanca";
            this.Txtdistanca.Size = new System.Drawing.Size(254, 31);
            this.Txtdistanca.TabIndex = 23;
            this.Txtdistanca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(10, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "Distanca e gjuajtjes ne metra";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(247, 130);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(247, 314);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(247, 189);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(28, 31);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // txtMaxPlumba
            // 
            this.txtMaxPlumba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtMaxPlumba.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMaxPlumba.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaxPlumba.ForeColor = System.Drawing.Color.White;
            this.txtMaxPlumba.Location = new System.Drawing.Point(281, 314);
            this.txtMaxPlumba.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtMaxPlumba.Multiline = true;
            this.txtMaxPlumba.Name = "txtMaxPlumba";
            this.txtMaxPlumba.Size = new System.Drawing.Size(254, 31);
            this.txtMaxPlumba.TabIndex = 16;
            this.txtMaxPlumba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtKalibri
            // 
            this.txtKalibri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtKalibri.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtKalibri.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKalibri.ForeColor = System.Drawing.Color.White;
            this.txtKalibri.Location = new System.Drawing.Point(281, 189);
            this.txtKalibri.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtKalibri.Multiline = true;
            this.txtKalibri.Name = "txtKalibri";
            this.txtKalibri.Size = new System.Drawing.Size(254, 31);
            this.txtKalibri.TabIndex = 15;
            this.txtKalibri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnRegjistroGjuajtjen
            // 
            this.btnRegjistroGjuajtjen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroGjuajtjen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroGjuajtjen.ButtonText = "Regjistro Gjuajtjen";
            this.btnRegjistroGjuajtjen.CausesValidation = false;
            this.btnRegjistroGjuajtjen.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroGjuajtjen.ErrorImageLeft")));
            this.btnRegjistroGjuajtjen.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btnRegjistroGjuajtjen.ErrorImageRight")));
            this.btnRegjistroGjuajtjen.FocusBackground = System.Drawing.Color.Empty;
            this.btnRegjistroGjuajtjen.FocusFontColor = System.Drawing.Color.Empty;
            this.btnRegjistroGjuajtjen.ForeColors = System.Drawing.Color.White;
            this.btnRegjistroGjuajtjen.HoverBackground = System.Drawing.Color.DarkSlateGray;
            this.btnRegjistroGjuajtjen.HoverFontColor = System.Drawing.Color.Transparent;
            this.btnRegjistroGjuajtjen.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroGjuajtjen.ImageLeft")));
            this.btnRegjistroGjuajtjen.ImageRight = null;
            this.btnRegjistroGjuajtjen.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroGjuajtjen.Location = new System.Drawing.Point(281, 379);
            this.btnRegjistroGjuajtjen.Name = "btnRegjistroGjuajtjen";
            this.btnRegjistroGjuajtjen.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroGjuajtjen.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroGjuajtjen.RightPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroGjuajtjen.Size = new System.Drawing.Size(254, 43);
            this.btnRegjistroGjuajtjen.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btnRegjistroGjuajtjen.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btnRegjistroGjuajtjen.TabIndex = 13;
            this.btnRegjistroGjuajtjen.Click += new System.EventHandler(this.btnRegjistroGjuajtjen_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(54, 323);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Plumbat e shfrytezuar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(97, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Piket e shenuara";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(112, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Selekto Klientin";
            // 
            // lblArma
            // 
            this.lblArma.AutoSize = true;
            this.lblArma.BackColor = System.Drawing.Color.Transparent;
            this.lblArma.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArma.ForeColor = System.Drawing.Color.White;
            this.lblArma.Location = new System.Drawing.Point(112, 139);
            this.lblArma.Name = "lblArma";
            this.lblArma.Size = new System.Drawing.Size(114, 20);
            this.lblArma.TabIndex = 8;
            this.lblArma.Text = "Selekto Armen";
            // 
            // armaTableAdapter
            // 
            this.armaTableAdapter.ClearBeforeFill = true;
            // 
            // useratTableAdapter1
            // 
            this.useratTableAdapter1.ClearBeforeFill = true;
            // 
            // btneditogjujtjen
            // 
            this.btneditogjujtjen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btneditogjujtjen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btneditogjujtjen.ButtonText = "Edito Gjuajtjen";
            this.btneditogjujtjen.CausesValidation = false;
            this.btneditogjujtjen.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btneditogjujtjen.ErrorImageLeft")));
            this.btneditogjujtjen.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btneditogjujtjen.ErrorImageRight")));
            this.btneditogjujtjen.FocusBackground = System.Drawing.Color.Empty;
            this.btneditogjujtjen.FocusFontColor = System.Drawing.Color.Empty;
            this.btneditogjujtjen.ForeColors = System.Drawing.Color.White;
            this.btneditogjujtjen.HoverBackground = System.Drawing.Color.DarkSlateGray;
            this.btneditogjujtjen.HoverFontColor = System.Drawing.Color.Transparent;
            this.btneditogjujtjen.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btneditogjujtjen.ImageLeft")));
            this.btneditogjujtjen.ImageRight = null;
            this.btneditogjujtjen.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btneditogjujtjen.Location = new System.Drawing.Point(281, 379);
            this.btneditogjujtjen.Name = "btneditogjujtjen";
            this.btneditogjujtjen.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btneditogjujtjen.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btneditogjujtjen.RightPictureColor = System.Drawing.Color.Transparent;
            this.btneditogjujtjen.Size = new System.Drawing.Size(254, 43);
            this.btneditogjujtjen.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btneditogjujtjen.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btneditogjujtjen.TabIndex = 40;
            this.btneditogjujtjen.Click += new System.EventHandler(this.jFlatButton1_Click);
            // 
            // frmRegjistroGjuajtjen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 450);
            this.Controls.Add(this.jGradientPanel1);
            this.Name = "frmRegjistroGjuajtjen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmRegjistroGjuajtjen";
            this.Load += new System.EventHandler(this.frmRegjistroGjuajtjen_Load);
            this.jGradientPanel1.ResumeLayout(false);
            this.jGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.useratBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_A62C25_poligoniDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_A62C25_poligoniDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.useratBindingSource)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private JGradient_Panel.JGradientPanel jGradientPanel1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.TextBox txtMaxPlumba;
		private System.Windows.Forms.TextBox txtKalibri;
		private FlatButton.JFlatButton btnRegjistroGjuajtjen;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lblArma;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.TextBox Txtdistanca;
		private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox droparmet;
        private DB_A62C25_poligoniDataSet dB_A62C25_poligoniDataSet;
        private System.Windows.Forms.BindingSource armaBindingSource;
        private DB_A62C25_poligoniDataSetTableAdapters.ArmaTableAdapter armaTableAdapter;
        private System.Windows.Forms.ComboBox dropklientat;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label3;

        private System.Windows.Forms.BindingSource useratBindingSource;

        private DB_A62C25_poligoniDataSet2 dB_A62C25_poligoniDataSet2;
        private System.Windows.Forms.BindingSource useratBindingSource1;
        private DB_A62C25_poligoniDataSet2TableAdapters.UseratTableAdapter useratTableAdapter1;
        private FlatButton.JFlatButton btneditogjujtjen;
    }
}