﻿namespace Poligoni
{
    partial class frmRegjistrimiArmes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegjistrimiArmes));
            this.jTextBox1 = new JTextBox2.JTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.jTextBox2 = new JTextBox2.JTextBox();
            this.jTextBox3 = new JTextBox2.JTextBox();
            this.btnRegjistro = new FlatButton.JFlatButton();
            this.jGradientPanel1 = new JGradient_Panel.JGradientPanel();
            this.btnEdito = new FlatButton.JFlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txtMaxPlumba = new System.Windows.Forms.TextBox();
            this.txtKalibri = new System.Windows.Forms.TextBox();
            this.txtEmriArmes = new System.Windows.Forms.TextBox();
            this.btnRegjistroArmen = new FlatButton.JFlatButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.jGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // jTextBox1
            // 
            this.jTextBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.jTextBox1.Font_Size = new System.Drawing.Font("Century Gothic", 11.25F);
            this.jTextBox1.HintText = null;
            this.jTextBox1.IsPassword = false;
            this.jTextBox1.Location = new System.Drawing.Point(739, 91);
            this.jTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.jTextBox1.MaxLength = 32767;
            this.jTextBox1.Name = "jTextBox1";
            this.jTextBox1.OnFocusedColor = System.Drawing.Color.White;
            this.jTextBox1.OnFocusedTextColor = System.Drawing.Color.Gray;
            this.jTextBox1.ReadOnly = false;
            this.jTextBox1.Right_To_Left = System.Windows.Forms.RightToLeft.No;
            this.jTextBox1.Size = new System.Drawing.Size(279, 38);
            this.jTextBox1.TabIndex = 0;
            this.jTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jTextBox1.TextName = "";
            this.jTextBox1.Load += new System.EventHandler(this.jTextBox1_Load);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(623, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Emri Armes";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(667, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Kalibri";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(621, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "MaxPlumba";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // jTextBox2
            // 
            this.jTextBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.jTextBox2.Font_Size = new System.Drawing.Font("Century Gothic", 11.25F);
            this.jTextBox2.HintText = null;
            this.jTextBox2.IsPassword = false;
            this.jTextBox2.Location = new System.Drawing.Point(739, 150);
            this.jTextBox2.Margin = new System.Windows.Forms.Padding(4);
            this.jTextBox2.MaxLength = 32767;
            this.jTextBox2.Name = "jTextBox2";
            this.jTextBox2.OnFocusedColor = System.Drawing.Color.White;
            this.jTextBox2.OnFocusedTextColor = System.Drawing.Color.Gray;
            this.jTextBox2.ReadOnly = false;
            this.jTextBox2.Right_To_Left = System.Windows.Forms.RightToLeft.No;
            this.jTextBox2.Size = new System.Drawing.Size(279, 38);
            this.jTextBox2.TabIndex = 4;
            this.jTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jTextBox2.TextName = "";
            this.jTextBox2.Load += new System.EventHandler(this.jTextBox2_Load);
            // 
            // jTextBox3
            // 
            this.jTextBox3.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.jTextBox3.Font_Size = new System.Drawing.Font("Century Gothic", 11.25F);
            this.jTextBox3.HintText = null;
            this.jTextBox3.IsPassword = false;
            this.jTextBox3.Location = new System.Drawing.Point(739, 211);
            this.jTextBox3.Margin = new System.Windows.Forms.Padding(4);
            this.jTextBox3.MaxLength = 32767;
            this.jTextBox3.Name = "jTextBox3";
            this.jTextBox3.OnFocusedColor = System.Drawing.Color.White;
            this.jTextBox3.OnFocusedTextColor = System.Drawing.Color.Gray;
            this.jTextBox3.ReadOnly = false;
            this.jTextBox3.Right_To_Left = System.Windows.Forms.RightToLeft.No;
            this.jTextBox3.Size = new System.Drawing.Size(279, 38);
            this.jTextBox3.TabIndex = 5;
            this.jTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jTextBox3.TextName = "";
            this.jTextBox3.Load += new System.EventHandler(this.jTextBox3_Load);
            // 
            // btnRegjistro
            // 
            this.btnRegjistro.BackColor = System.Drawing.Color.OliveDrab;
            this.btnRegjistro.BackgroundColor = System.Drawing.Color.OliveDrab;
            this.btnRegjistro.ButtonText = "Regjistro Armen";
            this.btnRegjistro.CausesValidation = false;
            this.btnRegjistro.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistro.ErrorImageLeft")));
            this.btnRegjistro.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btnRegjistro.ErrorImageRight")));
            this.btnRegjistro.FocusBackground = System.Drawing.Color.Empty;
            this.btnRegjistro.FocusFontColor = System.Drawing.Color.Empty;
            this.btnRegjistro.ForeColors = System.Drawing.Color.White;
            this.btnRegjistro.HoverBackground = System.Drawing.Color.Empty;
            this.btnRegjistro.HoverFontColor = System.Drawing.Color.Empty;
            this.btnRegjistro.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistro.ImageLeft")));
            this.btnRegjistro.ImageRight = null;
            this.btnRegjistro.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistro.Location = new System.Drawing.Point(753, 273);
            this.btnRegjistro.Name = "btnRegjistro";
            this.btnRegjistro.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistro.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistro.RightPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistro.Size = new System.Drawing.Size(254, 43);
            this.btnRegjistro.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btnRegjistro.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btnRegjistro.TabIndex = 6;
            this.btnRegjistro.Click += new System.EventHandler(this.btnRegjistro_Click);
            // 
            // jGradientPanel1
            // 
            this.jGradientPanel1.BackColor = System.Drawing.Color.DarkCyan;
            this.jGradientPanel1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.Controls.Add(this.btnEdito);
            this.jGradientPanel1.Controls.Add(this.pictureBox2);
            this.jGradientPanel1.Controls.Add(this.pictureBox1);
            this.jGradientPanel1.Controls.Add(this.pictureBox4);
            this.jGradientPanel1.Controls.Add(this.txtMaxPlumba);
            this.jGradientPanel1.Controls.Add(this.txtKalibri);
            this.jGradientPanel1.Controls.Add(this.txtEmriArmes);
            this.jGradientPanel1.Controls.Add(this.btnRegjistroArmen);
            this.jGradientPanel1.Controls.Add(this.label4);
            this.jGradientPanel1.Controls.Add(this.label5);
            this.jGradientPanel1.Controls.Add(this.label6);
            this.jGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.jGradientPanel1.Name = "jGradientPanel1";
            this.jGradientPanel1.Size = new System.Drawing.Size(720, 379);
            this.jGradientPanel1.TabIndex = 7;
            this.jGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.jGradientPanel1_Paint);
            // 
            // btnEdito
            // 
            this.btnEdito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnEdito.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnEdito.ButtonText = "Edito";
            this.btnEdito.CausesValidation = false;
            this.btnEdito.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btnEdito.ErrorImageLeft")));
            this.btnEdito.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btnEdito.ErrorImageRight")));
            this.btnEdito.FocusBackground = System.Drawing.Color.Empty;
            this.btnEdito.FocusFontColor = System.Drawing.Color.Empty;
            this.btnEdito.ForeColors = System.Drawing.Color.White;
            this.btnEdito.HoverBackground = System.Drawing.Color.DarkSlateGray;
            this.btnEdito.HoverFontColor = System.Drawing.Color.Transparent;
            this.btnEdito.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btnEdito.ImageLeft")));
            this.btnEdito.ImageRight = null;
            this.btnEdito.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btnEdito.Location = new System.Drawing.Point(240, 254);
            this.btnEdito.Name = "btnEdito";
            this.btnEdito.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btnEdito.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btnEdito.RightPictureColor = System.Drawing.Color.Transparent;
            this.btnEdito.Size = new System.Drawing.Size(254, 43);
            this.btnEdito.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btnEdito.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btnEdito.TabIndex = 21;
            this.btnEdito.Click += new System.EventHandler(this.btnEdito_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(206, 90);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(206, 201);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(206, 149);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(28, 31);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // txtMaxPlumba
            // 
            this.txtMaxPlumba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtMaxPlumba.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMaxPlumba.Font = new System.Drawing.Font("Montserrat", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaxPlumba.ForeColor = System.Drawing.Color.White;
            this.txtMaxPlumba.Location = new System.Drawing.Point(240, 201);
            this.txtMaxPlumba.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtMaxPlumba.Multiline = true;
            this.txtMaxPlumba.Name = "txtMaxPlumba";
            this.txtMaxPlumba.Size = new System.Drawing.Size(254, 31);
            this.txtMaxPlumba.TabIndex = 16;
            this.txtMaxPlumba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMaxPlumba.TextChanged += new System.EventHandler(this.txtMaxPlumba_TextChanged);
            // 
            // txtKalibri
            // 
            this.txtKalibri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtKalibri.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtKalibri.Font = new System.Drawing.Font("Montserrat", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKalibri.ForeColor = System.Drawing.Color.White;
            this.txtKalibri.Location = new System.Drawing.Point(240, 149);
            this.txtKalibri.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtKalibri.Multiline = true;
            this.txtKalibri.Name = "txtKalibri";
            this.txtKalibri.Size = new System.Drawing.Size(254, 31);
            this.txtKalibri.TabIndex = 15;
            this.txtKalibri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtKalibri.TextChanged += new System.EventHandler(this.txtKalibri_TextChanged);
            // 
            // txtEmriArmes
            // 
            this.txtEmriArmes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtEmriArmes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmriArmes.Font = new System.Drawing.Font("Montserrat", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmriArmes.ForeColor = System.Drawing.Color.White;
            this.txtEmriArmes.Location = new System.Drawing.Point(240, 90);
            this.txtEmriArmes.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtEmriArmes.Multiline = true;
            this.txtEmriArmes.Name = "txtEmriArmes";
            this.txtEmriArmes.Size = new System.Drawing.Size(254, 31);
            this.txtEmriArmes.TabIndex = 14;
            this.txtEmriArmes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtEmriArmes.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnRegjistroArmen
            // 
            this.btnRegjistroArmen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroArmen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroArmen.ButtonText = "Regjistro Armen";
            this.btnRegjistroArmen.CausesValidation = false;
            this.btnRegjistroArmen.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroArmen.ErrorImageLeft")));
            this.btnRegjistroArmen.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btnRegjistroArmen.ErrorImageRight")));
            this.btnRegjistroArmen.FocusBackground = System.Drawing.Color.Empty;
            this.btnRegjistroArmen.FocusFontColor = System.Drawing.Color.Empty;
            this.btnRegjistroArmen.ForeColors = System.Drawing.Color.White;
            this.btnRegjistroArmen.HoverBackground = System.Drawing.Color.DarkSlateGray;
            this.btnRegjistroArmen.HoverFontColor = System.Drawing.Color.Transparent;
            this.btnRegjistroArmen.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroArmen.ImageLeft")));
            this.btnRegjistroArmen.ImageRight = null;
            this.btnRegjistroArmen.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroArmen.Location = new System.Drawing.Point(240, 254);
            this.btnRegjistroArmen.Name = "btnRegjistroArmen";
            this.btnRegjistroArmen.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroArmen.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroArmen.RightPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroArmen.Size = new System.Drawing.Size(254, 43);
            this.btnRegjistroArmen.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btnRegjistroArmen.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btnRegjistroArmen.TabIndex = 13;
            this.btnRegjistroArmen.Click += new System.EventHandler(this.jFlatButton1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(83, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "MaxPlumba";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(130, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Kalibri";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(85, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "Emri Armes";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // frmRegjistrimiArmes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(720, 379);
            this.Controls.Add(this.jGradientPanel1);
            this.Controls.Add(this.btnRegjistro);
            this.Controls.Add(this.jTextBox3);
            this.Controls.Add(this.jTextBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.jTextBox1);
            this.Name = "frmRegjistrimiArmes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegjistrimiArmes";
            this.Load += new System.EventHandler(this.RegjistrimiArmes_Load);
            this.jGradientPanel1.ResumeLayout(false);
            this.jGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private JTextBox2.JTextBox jTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private JTextBox2.JTextBox jTextBox2;
        private JTextBox2.JTextBox jTextBox3;
        private FlatButton.JFlatButton btnRegjistro;
        private JGradient_Panel.JGradientPanel jGradientPanel1;
        private FlatButton.JFlatButton btnRegjistroArmen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtEmriArmes;
		private System.Windows.Forms.TextBox txtMaxPlumba;
		private System.Windows.Forms.TextBox txtKalibri;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox4;
        private FlatButton.JFlatButton btnEdito;
    }
}