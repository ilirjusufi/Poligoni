﻿namespace Poligoni
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.btnAnulo = new System.Windows.Forms.Button();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.btnKyqu = new System.Windows.Forms.Button();
            this.jGradientPanel1 = new JGradient_Panel.JGradientPanel();
            this.gunaControlBox1 = new Guna.UI.WinForms.GunaControlBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.txtuser1 = new System.Windows.Forms.TextBox();
            this.btnanuloo = new System.Windows.Forms.Button();
            this.txtpass2 = new System.Windows.Forms.TextBox();
            this.btnkyquu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.jGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(72, 255);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(28, 31);
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(72, 209);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 31);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(115, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(139, 138);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // txtUser
            // 
            this.txtUser.BackColor = System.Drawing.Color.SeaGreen;
            this.txtUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.ForeColor = System.Drawing.Color.White;
            this.txtUser.Location = new System.Drawing.Point(100, 209);
            this.txtUser.Multiline = true;
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(199, 31);
            this.txtUser.TabIndex = 5;
            this.txtUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAnulo
            // 
            this.btnAnulo.BackColor = System.Drawing.Color.SeaGreen;
            this.btnAnulo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAnulo.FlatAppearance.BorderSize = 2;
            this.btnAnulo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnulo.ForeColor = System.Drawing.Color.White;
            this.btnAnulo.Location = new System.Drawing.Point(216, 313);
            this.btnAnulo.Name = "btnAnulo";
            this.btnAnulo.Size = new System.Drawing.Size(98, 42);
            this.btnAnulo.TabIndex = 7;
            this.btnAnulo.Text = "Anulo";
            this.btnAnulo.UseVisualStyleBackColor = false;
            // 
            // txtPass
            // 
            this.txtPass.BackColor = System.Drawing.Color.SeaGreen;
            this.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPass.ForeColor = System.Drawing.Color.White;
            this.txtPass.Location = new System.Drawing.Point(100, 257);
            this.txtPass.Multiline = true;
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '#';
            this.txtPass.Size = new System.Drawing.Size(199, 29);
            this.txtPass.TabIndex = 6;
            this.txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnKyqu
            // 
            this.btnKyqu.BackColor = System.Drawing.Color.SeaGreen;
            this.btnKyqu.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnKyqu.FlatAppearance.BorderSize = 2;
            this.btnKyqu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKyqu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKyqu.ForeColor = System.Drawing.Color.White;
            this.btnKyqu.Location = new System.Drawing.Point(53, 313);
            this.btnKyqu.Name = "btnKyqu";
            this.btnKyqu.Size = new System.Drawing.Size(98, 42);
            this.btnKyqu.TabIndex = 8;
            this.btnKyqu.Text = "Kyqu";
            this.btnKyqu.UseVisualStyleBackColor = false;
            // 
            // jGradientPanel1
            // 
            this.jGradientPanel1.BackColor = System.Drawing.SystemColors.GrayText;
            this.jGradientPanel1.ColorBottom = System.Drawing.Color.PapayaWhip;
            this.jGradientPanel1.ColorTop = System.Drawing.Color.Olive;
            this.jGradientPanel1.Controls.Add(this.gunaControlBox1);
            this.jGradientPanel1.Controls.Add(this.pictureBox4);
            this.jGradientPanel1.Controls.Add(this.pictureBox5);
            this.jGradientPanel1.Controls.Add(this.txtuser1);
            this.jGradientPanel1.Controls.Add(this.btnanuloo);
            this.jGradientPanel1.Controls.Add(this.txtpass2);
            this.jGradientPanel1.Controls.Add(this.btnkyquu);
            this.jGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.jGradientPanel1.Name = "jGradientPanel1";
            this.jGradientPanel1.Size = new System.Drawing.Size(455, 510);
            this.jGradientPanel1.TabIndex = 12;
            this.jGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.jGradientPanel1_Paint);
            // 
            // gunaControlBox1
            // 
            this.gunaControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox1.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox1.AnimationSpeed = 0.03F;
            this.gunaControlBox1.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox1.IconSize = 15F;
            this.gunaControlBox1.Location = new System.Drawing.Point(385, 0);
            this.gunaControlBox1.Name = "gunaControlBox1";
            this.gunaControlBox1.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.gunaControlBox1.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox1.Size = new System.Drawing.Size(70, 29);
            this.gunaControlBox1.TabIndex = 5;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(126, 221);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(28, 31);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(126, 175);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(28, 31);
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            // 
            // txtuser1
            // 
            this.txtuser1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtuser1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtuser1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtuser1.ForeColor = System.Drawing.Color.Black;
            this.txtuser1.Location = new System.Drawing.Point(154, 175);
            this.txtuser1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtuser1.Multiline = true;
            this.txtuser1.Name = "txtuser1";
            this.txtuser1.Size = new System.Drawing.Size(199, 31);
            this.txtuser1.TabIndex = 0;
            this.txtuser1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnanuloo
            // 
            this.btnanuloo.BackColor = System.Drawing.Color.Silver;
            this.btnanuloo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnanuloo.FlatAppearance.BorderSize = 2;
            this.btnanuloo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnanuloo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnanuloo.ForeColor = System.Drawing.Color.White;
            this.btnanuloo.Location = new System.Drawing.Point(270, 279);
            this.btnanuloo.Name = "btnanuloo";
            this.btnanuloo.Size = new System.Drawing.Size(98, 42);
            this.btnanuloo.TabIndex = 1;
            this.btnanuloo.Text = "Anulo";
            this.btnanuloo.UseVisualStyleBackColor = false;
            // 
            // txtpass2
            // 
            this.txtpass2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtpass2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtpass2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpass2.ForeColor = System.Drawing.Color.Black;
            this.txtpass2.Location = new System.Drawing.Point(154, 223);
            this.txtpass2.Multiline = true;
            this.txtpass2.Name = "txtpass2";
            this.txtpass2.PasswordChar = '*';
            this.txtpass2.Size = new System.Drawing.Size(199, 29);
            this.txtpass2.TabIndex = 0;
            this.txtpass2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnkyquu
            // 
            this.btnkyquu.BackColor = System.Drawing.Color.Silver;
            this.btnkyquu.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnkyquu.FlatAppearance.BorderSize = 2;
            this.btnkyquu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkyquu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnkyquu.ForeColor = System.Drawing.Color.White;
            this.btnkyquu.Location = new System.Drawing.Point(107, 279);
            this.btnkyquu.Name = "btnkyquu";
            this.btnkyquu.Size = new System.Drawing.Size(98, 42);
            this.btnkyquu.TabIndex = 1;
            this.btnkyquu.Text = "Kyqu";
            this.btnkyquu.UseVisualStyleBackColor = false;
            this.btnkyquu.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 510);
            this.Controls.Add(this.jGradientPanel1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.btnAnulo);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.btnKyqu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(455, 510);
            this.MinimumSize = new System.Drawing.Size(455, 510);
            this.Name = "frmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.frmLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.jGradientPanel1.ResumeLayout(false);
            this.jGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Button btnAnulo;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Button btnKyqu;
		private JGradient_Panel.JGradientPanel jGradientPanel1;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.TextBox txtuser1;
		private System.Windows.Forms.Button btnanuloo;
		private System.Windows.Forms.TextBox txtpass2;
		private System.Windows.Forms.Button btnkyquu;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox1;
    }
}