﻿namespace Poligoni
{
    public class gjuha
    {

        public static string Gjuha = "sq-al";


    }
}
