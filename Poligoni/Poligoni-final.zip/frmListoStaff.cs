﻿using System.Windows.Forms;

namespace Poligoni
{
    public partial class frmListoStaff : Form
    {
        public frmListoStaff()
        {
            InitializeComponent();
        }
    }
}
