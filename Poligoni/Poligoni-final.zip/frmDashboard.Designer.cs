﻿namespace Poligoni
{
    partial class FrmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDashboard));
            this.panel4 = new System.Windows.Forms.Panel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnRegjistroGjuajtje = new Guna.UI2.WinForms.Guna2Button();
            this.btnregjistroplumba = new Guna.UI2.WinForms.Guna2Button();
            this.btnregjistoklienta = new Guna.UI2.WinForms.Guna2Button();
            this.btnregjistroarm = new Guna.UI2.WinForms.Guna2Button();
            this.lblemrimbiemri = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.jGradientPanel1 = new JGradient_Panel.JGradientPanel();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.financatrrethi = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label15 = new System.Windows.Forms.Label();
            this.lblgjuajtjemuaj = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar2 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label14 = new System.Windows.Forms.Label();
            this.lblklientamuaj = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar3 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label12 = new System.Windows.Forms.Label();
            this.lblaremtregjistruar = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar5 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label13 = new System.Windows.Forms.Label();
            this.lblplumbastok = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblklientaregjistrum = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2CircleProgressBar1 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.guna2CircleProgressBar4 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label11 = new System.Windows.Forms.Label();
            this.lblgjuajtjet = new System.Windows.Forms.Label();
            this.lbldata = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblemri = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.administrimiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroStafToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ndyshoStafToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.klientatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroKlientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listoKlientToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.armetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menaxhoArmetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.plumbatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroPlumbaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menaxhoPlumbatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gjuajtjaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regjistroGjuajtjenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listoTeGjithaGjuajtjetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ndimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.perAplikacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manualiIPerdorimitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.jGradientPanel1.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel4.Controls.Add(this.guna2Button1);
            this.panel4.Controls.Add(this.btnRegjistroGjuajtje);
            this.panel4.Controls.Add(this.btnregjistroplumba);
            this.panel4.Controls.Add(this.btnregjistoklienta);
            this.panel4.Controls.Add(this.btnregjistroarm);
            this.panel4.Controls.Add(this.lblemrimbiemri);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Name = "panel4";
            this.helpProvider1.SetShowHelp(this.panel4, ((bool)(resources.GetObject("panel4.ShowHelp"))));
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // guna2Button1
            // 
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            resources.ApplyResources(this.guna2Button1, "guna2Button1");
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.helpProvider1.SetShowHelp(this.guna2Button1, ((bool)(resources.GetObject("guna2Button1.ShowHelp"))));
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // btnRegjistroGjuajtje
            // 
            this.btnRegjistroGjuajtje.CheckedState.Parent = this.btnRegjistroGjuajtje;
            this.btnRegjistroGjuajtje.CustomImages.Parent = this.btnRegjistroGjuajtje;
            this.btnRegjistroGjuajtje.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            resources.ApplyResources(this.btnRegjistroGjuajtje, "btnRegjistroGjuajtje");
            this.btnRegjistroGjuajtje.ForeColor = System.Drawing.Color.White;
            this.btnRegjistroGjuajtje.HoverState.Parent = this.btnRegjistroGjuajtje;
            this.btnRegjistroGjuajtje.Name = "btnRegjistroGjuajtje";
            this.btnRegjistroGjuajtje.ShadowDecoration.Parent = this.btnRegjistroGjuajtje;
            this.helpProvider1.SetShowHelp(this.btnRegjistroGjuajtje, ((bool)(resources.GetObject("btnRegjistroGjuajtje.ShowHelp"))));
            this.btnRegjistroGjuajtje.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnRegjistroGjuajtje.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.btnRegjistroGjuajtje.Click += new System.EventHandler(this.btnRegjistroGjuajtje_Click);
            // 
            // btnregjistroplumba
            // 
            this.btnregjistroplumba.CheckedState.Parent = this.btnregjistroplumba;
            this.btnregjistroplumba.CustomImages.Parent = this.btnregjistroplumba;
            this.btnregjistroplumba.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            resources.ApplyResources(this.btnregjistroplumba, "btnregjistroplumba");
            this.btnregjistroplumba.ForeColor = System.Drawing.Color.White;
            this.btnregjistroplumba.HoverState.Parent = this.btnregjistroplumba;
            this.btnregjistroplumba.Name = "btnregjistroplumba";
            this.btnregjistroplumba.ShadowDecoration.Parent = this.btnregjistroplumba;
            this.helpProvider1.SetShowHelp(this.btnregjistroplumba, ((bool)(resources.GetObject("btnregjistroplumba.ShowHelp"))));
            this.btnregjistroplumba.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnregjistroplumba.Click += new System.EventHandler(this.btnregjistroplumba_Click);
            // 
            // btnregjistoklienta
            // 
            this.btnregjistoklienta.CheckedState.Parent = this.btnregjistoklienta;
            this.btnregjistoklienta.CustomImages.Parent = this.btnregjistoklienta;
            this.btnregjistoklienta.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            resources.ApplyResources(this.btnregjistoklienta, "btnregjistoklienta");
            this.btnregjistoklienta.ForeColor = System.Drawing.Color.White;
            this.btnregjistoklienta.HoverState.Parent = this.btnregjistoklienta;
            this.btnregjistoklienta.Name = "btnregjistoklienta";
            this.btnregjistoklienta.ShadowDecoration.Parent = this.btnregjistoklienta;
            this.helpProvider1.SetShowHelp(this.btnregjistoklienta, ((bool)(resources.GetObject("btnregjistoklienta.ShowHelp"))));
            this.btnregjistoklienta.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnregjistoklienta.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.btnregjistoklienta.Click += new System.EventHandler(this.btnregjistoklienta_Click);
            // 
            // btnregjistroarm
            // 
            this.btnregjistroarm.CheckedState.Parent = this.btnregjistroarm;
            this.btnregjistroarm.CustomImages.Parent = this.btnregjistroarm;
            this.btnregjistroarm.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            resources.ApplyResources(this.btnregjistroarm, "btnregjistroarm");
            this.btnregjistroarm.ForeColor = System.Drawing.Color.White;
            this.btnregjistroarm.HoverState.Parent = this.btnregjistroarm;
            this.btnregjistroarm.Name = "btnregjistroarm";
            this.btnregjistroarm.ShadowDecoration.Parent = this.btnregjistroarm;
            this.helpProvider1.SetShowHelp(this.btnregjistroarm, ((bool)(resources.GetObject("btnregjistroarm.ShowHelp"))));
            this.btnregjistroarm.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnregjistroarm.Click += new System.EventHandler(this.btnregjistroarm_Click);
            // 
            // lblemrimbiemri
            // 
            resources.ApplyResources(this.lblemrimbiemri, "lblemrimbiemri");
            this.lblemrimbiemri.ForeColor = System.Drawing.Color.LightGray;
            this.lblemrimbiemri.Name = "lblemrimbiemri";
            this.helpProvider1.SetShowHelp(this.lblemrimbiemri, ((bool)(resources.GetObject("lblemrimbiemri.ShowHelp"))));
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.LightGray;
            this.label5.Name = "label5";
            this.helpProvider1.SetShowHelp(this.label5, ((bool)(resources.GetObject("label5.ShowHelp"))));
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.LightGray;
            this.label2.Name = "label2";
            this.helpProvider1.SetShowHelp(this.label2, ((bool)(resources.GetObject("label2.ShowHelp"))));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Poligoni.Properties.Resources._20;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.helpProvider1.SetShowHelp(this.pictureBox1, ((bool)(resources.GetObject("pictureBox1.ShowHelp"))));
            this.pictureBox1.TabStop = false;
            // 
            // jGradientPanel1
            // 
            this.jGradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorBottom = System.Drawing.Color.Empty;
            this.jGradientPanel1.ColorTop = System.Drawing.Color.Empty;
            this.jGradientPanel1.Controls.Add(this.guna2CircleButton1);
            this.jGradientPanel1.Controls.Add(this.panel12);
            this.jGradientPanel1.Controls.Add(this.panel7);
            this.jGradientPanel1.Controls.Add(this.label3);
            this.jGradientPanel1.Controls.Add(this.panel6);
            this.jGradientPanel1.Controls.Add(this.lbldata);
            this.jGradientPanel1.Controls.Add(this.label18);
            this.jGradientPanel1.Controls.Add(this.lblemri);
            this.jGradientPanel1.Controls.Add(this.label1);
            this.jGradientPanel1.Controls.Add(this.menuStrip1);
            this.jGradientPanel1.Controls.Add(this.panel4);
            resources.ApplyResources(this.jGradientPanel1, "jGradientPanel1");
            this.jGradientPanel1.Name = "jGradientPanel1";
            this.helpProvider1.SetShowHelp(this.jGradientPanel1, ((bool)(resources.GetObject("jGradientPanel1.ShowHelp"))));
            this.jGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.jGradientPanel1_Paint);
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.Animated = true;
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.guna2CircleButton1, "guna2CircleButton1");
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.IndicateFocus = true;
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.helpProvider1.SetShowHelp(this.guna2CircleButton1, ((bool)(resources.GetObject("guna2CircleButton1.ShowHelp"))));
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel12.Controls.Add(this.panel13);
            this.panel12.Controls.Add(this.financatrrethi);
            this.panel12.Controls.Add(this.label15);
            this.panel12.Controls.Add(this.lblgjuajtjemuaj);
            this.panel12.Controls.Add(this.label17);
            resources.ApplyResources(this.panel12, "panel12");
            this.panel12.Name = "panel12";
            this.helpProvider1.SetShowHelp(this.panel12, ((bool)(resources.GetObject("panel12.ShowHelp"))));
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(179)))), ((int)(((byte)(133)))));
            resources.ApplyResources(this.panel13, "panel13");
            this.panel13.Name = "panel13";
            this.helpProvider1.SetShowHelp(this.panel13, ((bool)(resources.GetObject("panel13.ShowHelp"))));
            // 
            // financatrrethi
            // 
            resources.ApplyResources(this.financatrrethi, "financatrrethi");
            this.financatrrethi.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.financatrrethi.Name = "financatrrethi";
            this.financatrrethi.ProgressColor = System.Drawing.Color.White;
            this.financatrrethi.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.financatrrethi.ShadowDecoration.Parent = this.financatrrethi;
            this.helpProvider1.SetShowHelp(this.financatrrethi, ((bool)(resources.GetObject("financatrrethi.ShowHelp"))));
            this.financatrrethi.ShowPercentage = true;
            this.financatrrethi.Value = 3;
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.LightGray;
            this.label15.Name = "label15";
            this.helpProvider1.SetShowHelp(this.label15, ((bool)(resources.GetObject("label15.ShowHelp"))));
            // 
            // lblgjuajtjemuaj
            // 
            resources.ApplyResources(this.lblgjuajtjemuaj, "lblgjuajtjemuaj");
            this.lblgjuajtjemuaj.ForeColor = System.Drawing.Color.LightGray;
            this.lblgjuajtjemuaj.Name = "lblgjuajtjemuaj";
            this.helpProvider1.SetShowHelp(this.lblgjuajtjemuaj, ((bool)(resources.GetObject("lblgjuajtjemuaj.ShowHelp"))));
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.ForeColor = System.Drawing.Color.LightGray;
            this.label17.Name = "label17";
            this.helpProvider1.SetShowHelp(this.label17, ((bool)(resources.GetObject("label17.ShowHelp"))));
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel7.Controls.Add(this.panel14);
            this.panel7.Controls.Add(this.guna2CircleProgressBar2);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.lblklientamuaj);
            this.panel7.Controls.Add(this.label4);
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            this.helpProvider1.SetShowHelp(this.panel7, ((bool)(resources.GetObject("panel7.ShowHelp"))));
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(152)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.panel14, "panel14");
            this.panel14.Name = "panel14";
            this.helpProvider1.SetShowHelp(this.panel14, ((bool)(resources.GetObject("panel14.ShowHelp"))));
            // 
            // guna2CircleProgressBar2
            // 
            resources.ApplyResources(this.guna2CircleProgressBar2, "guna2CircleProgressBar2");
            this.guna2CircleProgressBar2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.guna2CircleProgressBar2.Name = "guna2CircleProgressBar2";
            this.guna2CircleProgressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(112)))), ((int)(((byte)(94)))));
            this.guna2CircleProgressBar2.ProgressColor2 = System.Drawing.Color.Olive;
            this.guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar2.ShadowDecoration.Parent = this.guna2CircleProgressBar2;
            this.helpProvider1.SetShowHelp(this.guna2CircleProgressBar2, ((bool)(resources.GetObject("guna2CircleProgressBar2.ShowHelp"))));
            this.guna2CircleProgressBar2.ShowPercentage = true;
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.LightGray;
            this.label14.Name = "label14";
            this.helpProvider1.SetShowHelp(this.label14, ((bool)(resources.GetObject("label14.ShowHelp"))));
            // 
            // lblklientamuaj
            // 
            resources.ApplyResources(this.lblklientamuaj, "lblklientamuaj");
            this.lblklientamuaj.ForeColor = System.Drawing.Color.LightGray;
            this.lblklientamuaj.Name = "lblklientamuaj";
            this.helpProvider1.SetShowHelp(this.lblklientamuaj, ((bool)(resources.GetObject("lblklientamuaj.ShowHelp"))));
            this.lblklientamuaj.Click += new System.EventHandler(this.lblfinancat_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.LightGray;
            this.label4.Name = "label4";
            this.helpProvider1.SetShowHelp(this.label4, ((bool)(resources.GetObject("label4.ShowHelp"))));
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.LightGray;
            this.label3.Name = "label3";
            this.helpProvider1.SetShowHelp(this.label3, ((bool)(resources.GetObject("label3.ShowHelp"))));
            // 
            // panel6
            // 
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Controls.Add(this.panel3);
            this.panel6.Controls.Add(this.panel5);
            this.panel6.Controls.Add(this.panel1);
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Name = "panel6";
            this.helpProvider1.SetShowHelp(this.panel6, ((bool)(resources.GetObject("panel6.ShowHelp"))));
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.guna2CircleProgressBar3);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.lblaremtregjistruar);
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            this.helpProvider1.SetShowHelp(this.panel3, ((bool)(resources.GetObject("panel3.ShowHelp"))));
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(136)))), ((int)(((byte)(114)))));
            resources.ApplyResources(this.panel10, "panel10");
            this.panel10.Name = "panel10";
            this.helpProvider1.SetShowHelp(this.panel10, ((bool)(resources.GetObject("panel10.ShowHelp"))));
            // 
            // guna2CircleProgressBar3
            // 
            this.guna2CircleProgressBar3.FillThickness = 5;
            this.guna2CircleProgressBar3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.guna2CircleProgressBar3, "guna2CircleProgressBar3");
            this.guna2CircleProgressBar3.Name = "guna2CircleProgressBar3";
            this.guna2CircleProgressBar3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.guna2CircleProgressBar3.ProgressThickness = 5;
            this.guna2CircleProgressBar3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar3.ShadowDecoration.Parent = this.guna2CircleProgressBar3;
            this.helpProvider1.SetShowHelp(this.guna2CircleProgressBar3, ((bool)(resources.GetObject("guna2CircleProgressBar3.ShowHelp"))));
            this.guna2CircleProgressBar3.ShowPercentage = true;
            this.guna2CircleProgressBar3.Value = 30;
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.LightGray;
            this.label12.Name = "label12";
            this.helpProvider1.SetShowHelp(this.label12, ((bool)(resources.GetObject("label12.ShowHelp"))));
            // 
            // lblaremtregjistruar
            // 
            resources.ApplyResources(this.lblaremtregjistruar, "lblaremtregjistruar");
            this.lblaremtregjistruar.ForeColor = System.Drawing.Color.LightGray;
            this.lblaremtregjistruar.Name = "lblaremtregjistruar";
            this.helpProvider1.SetShowHelp(this.lblaremtregjistruar, ((bool)(resources.GetObject("lblaremtregjistruar.ShowHelp"))));
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel5.Controls.Add(this.panel11);
            this.panel5.Controls.Add(this.guna2CircleProgressBar5);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.lblplumbastok);
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            this.helpProvider1.SetShowHelp(this.panel5, ((bool)(resources.GetObject("panel5.ShowHelp"))));
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(179)))), ((int)(((byte)(133)))));
            resources.ApplyResources(this.panel11, "panel11");
            this.panel11.Name = "panel11";
            this.helpProvider1.SetShowHelp(this.panel11, ((bool)(resources.GetObject("panel11.ShowHelp"))));
            // 
            // guna2CircleProgressBar5
            // 
            this.guna2CircleProgressBar5.FillThickness = 5;
            this.guna2CircleProgressBar5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.guna2CircleProgressBar5, "guna2CircleProgressBar5");
            this.guna2CircleProgressBar5.Name = "guna2CircleProgressBar5";
            this.guna2CircleProgressBar5.ProgressColor = System.Drawing.Color.White;
            this.guna2CircleProgressBar5.ProgressThickness = 5;
            this.guna2CircleProgressBar5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar5.ShadowDecoration.Parent = this.guna2CircleProgressBar5;
            this.helpProvider1.SetShowHelp(this.guna2CircleProgressBar5, ((bool)(resources.GetObject("guna2CircleProgressBar5.ShowHelp"))));
            this.guna2CircleProgressBar5.ShowPercentage = true;
            this.guna2CircleProgressBar5.Value = 30;
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.LightGray;
            this.label13.Name = "label13";
            this.helpProvider1.SetShowHelp(this.label13, ((bool)(resources.GetObject("label13.ShowHelp"))));
            // 
            // lblplumbastok
            // 
            resources.ApplyResources(this.lblplumbastok, "lblplumbastok");
            this.lblplumbastok.ForeColor = System.Drawing.Color.LightGray;
            this.lblplumbastok.Name = "lblplumbastok";
            this.helpProvider1.SetShowHelp(this.lblplumbastok, ((bool)(resources.GetObject("lblplumbastok.ShowHelp"))));
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.lblklientaregjistrum);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.guna2CircleProgressBar1);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            this.helpProvider1.SetShowHelp(this.panel1, ((bool)(resources.GetObject("panel1.ShowHelp"))));
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(179)))), ((int)(((byte)(133)))));
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Name = "panel8";
            this.helpProvider1.SetShowHelp(this.panel8, ((bool)(resources.GetObject("panel8.ShowHelp"))));
            // 
            // lblklientaregjistrum
            // 
            resources.ApplyResources(this.lblklientaregjistrum, "lblklientaregjistrum");
            this.lblklientaregjistrum.ForeColor = System.Drawing.Color.LightGray;
            this.lblklientaregjistrum.Name = "lblklientaregjistrum";
            this.helpProvider1.SetShowHelp(this.lblklientaregjistrum, ((bool)(resources.GetObject("lblklientaregjistrum.ShowHelp"))));
            this.lblklientaregjistrum.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.LightGray;
            this.label6.Name = "label6";
            this.helpProvider1.SetShowHelp(this.label6, ((bool)(resources.GetObject("label6.ShowHelp"))));
            // 
            // guna2CircleProgressBar1
            // 
            this.guna2CircleProgressBar1.FillThickness = 5;
            this.guna2CircleProgressBar1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.guna2CircleProgressBar1, "guna2CircleProgressBar1");
            this.guna2CircleProgressBar1.Name = "guna2CircleProgressBar1";
            this.guna2CircleProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.guna2CircleProgressBar1.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(174)))), ((int)(((byte)(182)))));
            this.guna2CircleProgressBar1.ProgressThickness = 5;
            this.guna2CircleProgressBar1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar1.ShadowDecoration.Parent = this.guna2CircleProgressBar1;
            this.helpProvider1.SetShowHelp(this.guna2CircleProgressBar1, ((bool)(resources.GetObject("guna2CircleProgressBar1.ShowHelp"))));
            this.guna2CircleProgressBar1.ShowPercentage = true;
            this.guna2CircleProgressBar1.Value = 30;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(45)))), ((int)(((byte)(71)))));
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.guna2CircleProgressBar4);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.lblgjuajtjet);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            this.helpProvider1.SetShowHelp(this.panel2, ((bool)(resources.GetObject("panel2.ShowHelp"))));
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(152)))), ((int)(((byte)(50)))));
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.Name = "panel9";
            this.helpProvider1.SetShowHelp(this.panel9, ((bool)(resources.GetObject("panel9.ShowHelp"))));
            // 
            // guna2CircleProgressBar4
            // 
            this.guna2CircleProgressBar4.FillThickness = 5;
            this.guna2CircleProgressBar4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            resources.ApplyResources(this.guna2CircleProgressBar4, "guna2CircleProgressBar4");
            this.guna2CircleProgressBar4.Name = "guna2CircleProgressBar4";
            this.guna2CircleProgressBar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2CircleProgressBar4.ProgressThickness = 5;
            this.guna2CircleProgressBar4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar4.ShadowDecoration.Parent = this.guna2CircleProgressBar4;
            this.helpProvider1.SetShowHelp(this.guna2CircleProgressBar4, ((bool)(resources.GetObject("guna2CircleProgressBar4.ShowHelp"))));
            this.guna2CircleProgressBar4.ShowPercentage = true;
            this.guna2CircleProgressBar4.Value = 30;
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.LightGray;
            this.label11.Name = "label11";
            this.helpProvider1.SetShowHelp(this.label11, ((bool)(resources.GetObject("label11.ShowHelp"))));
            // 
            // lblgjuajtjet
            // 
            resources.ApplyResources(this.lblgjuajtjet, "lblgjuajtjet");
            this.lblgjuajtjet.ForeColor = System.Drawing.Color.LightGray;
            this.lblgjuajtjet.Name = "lblgjuajtjet";
            this.helpProvider1.SetShowHelp(this.lblgjuajtjet, ((bool)(resources.GetObject("lblgjuajtjet.ShowHelp"))));
            // 
            // lbldata
            // 
            resources.ApplyResources(this.lbldata, "lbldata");
            this.lbldata.ForeColor = System.Drawing.Color.LightGray;
            this.lbldata.Name = "lbldata";
            this.helpProvider1.SetShowHelp(this.lbldata, ((bool)(resources.GetObject("lbldata.ShowHelp"))));
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.ForeColor = System.Drawing.Color.LightGray;
            this.label18.Name = "label18";
            this.helpProvider1.SetShowHelp(this.label18, ((bool)(resources.GetObject("label18.ShowHelp"))));
            // 
            // lblemri
            // 
            resources.ApplyResources(this.lblemri, "lblemri");
            this.lblemri.ForeColor = System.Drawing.Color.LightGray;
            this.lblemri.Name = "lblemri";
            this.helpProvider1.SetShowHelp(this.lblemri, ((bool)(resources.GetObject("lblemri.ShowHelp"))));
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Name = "label1";
            this.helpProvider1.SetShowHelp(this.label1, ((bool)(resources.GetObject("label1.ShowHelp"))));
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(13)))), ((int)(((byte)(32)))));
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.administrimiToolStripMenuItem,
            this.klientatToolStripMenuItem,
            this.armetToolStripMenuItem,
            this.plumbatToolStripMenuItem,
            this.gjuajtjaToolStripMenuItem,
            this.ndimaToolStripMenuItem});
            this.menuStrip1.Name = "menuStrip1";
            this.helpProvider1.SetShowHelp(this.menuStrip1, ((bool)(resources.GetObject("menuStrip1.ShowHelp"))));
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked_1);
            // 
            // administrimiToolStripMenuItem
            // 
            resources.ApplyResources(this.administrimiToolStripMenuItem, "administrimiToolStripMenuItem");
            this.administrimiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroStafToolStripMenuItem,
            this.ndyshoStafToolStripMenuItem});
            this.administrimiToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.administrimiToolStripMenuItem.Name = "administrimiToolStripMenuItem";
            // 
            // regjistroStafToolStripMenuItem
            // 
            resources.ApplyResources(this.regjistroStafToolStripMenuItem, "regjistroStafToolStripMenuItem");
            this.regjistroStafToolStripMenuItem.Name = "regjistroStafToolStripMenuItem";
            this.regjistroStafToolStripMenuItem.Click += new System.EventHandler(this.regjistroStafToolStripMenuItem_Click);
            // 
            // ndyshoStafToolStripMenuItem
            // 
            resources.ApplyResources(this.ndyshoStafToolStripMenuItem, "ndyshoStafToolStripMenuItem");
            this.ndyshoStafToolStripMenuItem.Name = "ndyshoStafToolStripMenuItem";
            this.ndyshoStafToolStripMenuItem.Click += new System.EventHandler(this.ndyshoStafToolStripMenuItem_Click);
            // 
            // klientatToolStripMenuItem
            // 
            this.klientatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroKlientToolStripMenuItem,
            this.listoKlientToolStripMenuItem1});
            this.klientatToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.klientatToolStripMenuItem.Name = "klientatToolStripMenuItem";
            resources.ApplyResources(this.klientatToolStripMenuItem, "klientatToolStripMenuItem");
            // 
            // regjistroKlientToolStripMenuItem
            // 
            resources.ApplyResources(this.regjistroKlientToolStripMenuItem, "regjistroKlientToolStripMenuItem");
            this.regjistroKlientToolStripMenuItem.Name = "regjistroKlientToolStripMenuItem";
            this.regjistroKlientToolStripMenuItem.Click += new System.EventHandler(this.regjistroKlientToolStripMenuItem_Click_4);
            // 
            // listoKlientToolStripMenuItem1
            // 
            resources.ApplyResources(this.listoKlientToolStripMenuItem1, "listoKlientToolStripMenuItem1");
            this.listoKlientToolStripMenuItem1.Name = "listoKlientToolStripMenuItem1";
            this.listoKlientToolStripMenuItem1.Click += new System.EventHandler(this.listoKlientToolStripMenuItem1_Click);
            // 
            // armetToolStripMenuItem
            // 
            this.armetToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroToolStripMenuItem,
            this.menaxhoArmetToolStripMenuItem});
            this.armetToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.armetToolStripMenuItem.Name = "armetToolStripMenuItem";
            resources.ApplyResources(this.armetToolStripMenuItem, "armetToolStripMenuItem");
            // 
            // regjistroToolStripMenuItem
            // 
            this.regjistroToolStripMenuItem.Image = global::Poligoni.Properties.Resources.gun;
            this.regjistroToolStripMenuItem.Name = "regjistroToolStripMenuItem";
            resources.ApplyResources(this.regjistroToolStripMenuItem, "regjistroToolStripMenuItem");
            this.regjistroToolStripMenuItem.Click += new System.EventHandler(this.regjistroToolStripMenuItem_Click);
            // 
            // menaxhoArmetToolStripMenuItem
            // 
            resources.ApplyResources(this.menaxhoArmetToolStripMenuItem, "menaxhoArmetToolStripMenuItem");
            this.menaxhoArmetToolStripMenuItem.Name = "menaxhoArmetToolStripMenuItem";
            this.menaxhoArmetToolStripMenuItem.Click += new System.EventHandler(this.menaxhoArmetToolStripMenuItem_Click);
            // 
            // plumbatToolStripMenuItem
            // 
            this.plumbatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroPlumbaToolStripMenuItem,
            this.menaxhoPlumbatToolStripMenuItem});
            this.plumbatToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.plumbatToolStripMenuItem.Name = "plumbatToolStripMenuItem";
            resources.ApplyResources(this.plumbatToolStripMenuItem, "plumbatToolStripMenuItem");
            // 
            // regjistroPlumbaToolStripMenuItem
            // 
            resources.ApplyResources(this.regjistroPlumbaToolStripMenuItem, "regjistroPlumbaToolStripMenuItem");
            this.regjistroPlumbaToolStripMenuItem.Name = "regjistroPlumbaToolStripMenuItem";
            this.regjistroPlumbaToolStripMenuItem.Click += new System.EventHandler(this.regjistroPlumbaToolStripMenuItem_Click);
            // 
            // menaxhoPlumbatToolStripMenuItem
            // 
            resources.ApplyResources(this.menaxhoPlumbatToolStripMenuItem, "menaxhoPlumbatToolStripMenuItem");
            this.menaxhoPlumbatToolStripMenuItem.Name = "menaxhoPlumbatToolStripMenuItem";
            this.menaxhoPlumbatToolStripMenuItem.Click += new System.EventHandler(this.menaxhoPlumbatToolStripMenuItem_Click);
            // 
            // gjuajtjaToolStripMenuItem
            // 
            this.gjuajtjaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.regjistroGjuajtjenToolStripMenuItem,
            this.listoTeGjithaGjuajtjetToolStripMenuItem});
            this.gjuajtjaToolStripMenuItem.ForeColor = System.Drawing.Color.DimGray;
            this.gjuajtjaToolStripMenuItem.Name = "gjuajtjaToolStripMenuItem";
            resources.ApplyResources(this.gjuajtjaToolStripMenuItem, "gjuajtjaToolStripMenuItem");
            // 
            // regjistroGjuajtjenToolStripMenuItem
            // 
            this.regjistroGjuajtjenToolStripMenuItem.Image = global::Poligoni.Properties.Resources._4;
            this.regjistroGjuajtjenToolStripMenuItem.Name = "regjistroGjuajtjenToolStripMenuItem";
            resources.ApplyResources(this.regjistroGjuajtjenToolStripMenuItem, "regjistroGjuajtjenToolStripMenuItem");
            this.regjistroGjuajtjenToolStripMenuItem.Click += new System.EventHandler(this.regjistroGjuajtjenToolStripMenuItem_Click);
            // 
            // listoTeGjithaGjuajtjetToolStripMenuItem
            // 
            this.listoTeGjithaGjuajtjetToolStripMenuItem.Name = "listoTeGjithaGjuajtjetToolStripMenuItem";
            resources.ApplyResources(this.listoTeGjithaGjuajtjetToolStripMenuItem, "listoTeGjithaGjuajtjetToolStripMenuItem");
            this.listoTeGjithaGjuajtjetToolStripMenuItem.Click += new System.EventHandler(this.listoTeGjithaGjuajtjetToolStripMenuItem_Click);
            // 
            // ndimaToolStripMenuItem
            // 
            this.ndimaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.perAplikacionToolStripMenuItem,
            this.manualiIPerdorimitToolStripMenuItem});
            this.ndimaToolStripMenuItem.ForeColor = System.Drawing.Color.Gray;
            this.ndimaToolStripMenuItem.Name = "ndimaToolStripMenuItem";
            resources.ApplyResources(this.ndimaToolStripMenuItem, "ndimaToolStripMenuItem");
            // 
            // perAplikacionToolStripMenuItem
            // 
            this.perAplikacionToolStripMenuItem.Name = "perAplikacionToolStripMenuItem";
            resources.ApplyResources(this.perAplikacionToolStripMenuItem, "perAplikacionToolStripMenuItem");
            this.perAplikacionToolStripMenuItem.Click += new System.EventHandler(this.perAplikacionToolStripMenuItem_Click);
            // 
            // manualiIPerdorimitToolStripMenuItem
            // 
            this.manualiIPerdorimitToolStripMenuItem.Name = "manualiIPerdorimitToolStripMenuItem";
            resources.ApplyResources(this.manualiIPerdorimitToolStripMenuItem, "manualiIPerdorimitToolStripMenuItem");
            this.manualiIPerdorimitToolStripMenuItem.Click += new System.EventHandler(this.manualiIPerdorimitToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // helpProvider1
            // 
            resources.ApplyResources(this.helpProvider1, "helpProvider1");
            // 
            // FrmDashboard
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.jGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FrmDashboard";
            this.helpProvider1.SetShowHelp(this, ((bool)(resources.GetObject("$this.ShowHelp"))));
            this.Load += new System.EventHandler(this.FrmDashboard_Load_1);
            this.Shown += new System.EventHandler(this.FrmDashboard_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.jGradientPanel1.ResumeLayout(false);
            this.jGradientPanel1.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblemrimbiemri;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private JGradient_Panel.JGradientPanel jGradientPanel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar4;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar3;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar5;
        private System.Windows.Forms.Panel panel8;
        private Guna.UI2.WinForms.Guna2Button btnregjistroarm;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblklientamuaj;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblaremtregjistruar;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblplumbastok;
        private System.Windows.Forms.Label lblklientaregjistrum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblgjuajtjet;
        private Guna.UI2.WinForms.Guna2Button btnregjistroplumba;
        private Guna.UI2.WinForms.Guna2Button btnregjistoklienta;
        private System.Windows.Forms.Panel panel12;
        private Guna.UI2.WinForms.Guna2CircleProgressBar financatrrethi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblgjuajtjemuaj;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbldata;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem administrimiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regjistroStafToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ndyshoStafToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem klientatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regjistroKlientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listoKlientToolStripMenuItem1;
        private System.Windows.Forms.Label lblemri;
		private Guna.UI2.WinForms.Guna2Button btnRegjistroGjuajtje;
		private System.Windows.Forms.ToolStripMenuItem gjuajtjaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem regjistroGjuajtjenToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem listoTeGjithaGjuajtjetToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.ToolStripMenuItem armetToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem regjistroToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem menaxhoArmetToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem plumbatToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem regjistroPlumbaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem menaxhoPlumbatToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private System.Windows.Forms.ToolStripMenuItem ndimaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem perAplikacionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manualiIPerdorimitToolStripMenuItem;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
    }
}