﻿namespace Poligoni
{
    class sqllidhja
    {

    }
}
