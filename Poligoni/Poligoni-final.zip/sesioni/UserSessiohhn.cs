﻿using Poligoni.BO;

namespace Poligoni
{
    public class UserSession
    {
        public static Users CurrentUser = null;
    }

}