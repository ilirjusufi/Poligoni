﻿namespace Poligoni
{
    partial class frmRegjistrimiPlumbave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegjistrimiPlumbave));
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.jGradientPanel1 = new JGradient_Panel.JGradientPanel();
            this.lblNdryshimi = new System.Windows.Forms.Label();
            this.btnNdryshoPlumbat = new FlatButton.JFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtSasia = new System.Windows.Forms.TextBox();
            this.txtKalibri = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRegjistroPlumbat = new FlatButton.JFlatButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.jGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(129, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Sasia";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(120, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "Kalibri";
            // 
            // jGradientPanel1
            // 
            this.jGradientPanel1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(28)))), ((int)(((byte)(48)))));
            this.jGradientPanel1.Controls.Add(this.lblNdryshimi);
            this.jGradientPanel1.Controls.Add(this.btnNdryshoPlumbat);
            this.jGradientPanel1.Controls.Add(this.pictureBox1);
            this.jGradientPanel1.Controls.Add(this.pictureBox2);
            this.jGradientPanel1.Controls.Add(this.txtSasia);
            this.jGradientPanel1.Controls.Add(this.txtKalibri);
            this.jGradientPanel1.Controls.Add(this.label1);
            this.jGradientPanel1.Controls.Add(this.btnRegjistroPlumbat);
            this.jGradientPanel1.Controls.Add(this.label6);
            this.jGradientPanel1.Controls.Add(this.label5);
            this.jGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.jGradientPanel1.Name = "jGradientPanel1";
            this.jGradientPanel1.Size = new System.Drawing.Size(696, 472);
            this.jGradientPanel1.TabIndex = 21;
            this.jGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.jGradientPanel1_Paint);
            // 
            // lblNdryshimi
            // 
            this.lblNdryshimi.AutoSize = true;
            this.lblNdryshimi.BackColor = System.Drawing.Color.Transparent;
            this.lblNdryshimi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNdryshimi.ForeColor = System.Drawing.Color.White;
            this.lblNdryshimi.Location = new System.Drawing.Point(249, 113);
            this.lblNdryshimi.Name = "lblNdryshimi";
            this.lblNdryshimi.Size = new System.Drawing.Size(192, 24);
            this.lblNdryshimi.TabIndex = 46;
            this.lblNdryshimi.Text = "Ndryshimi i Plumbave";
            // 
            // btnNdryshoPlumbat
            // 
            this.btnNdryshoPlumbat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnNdryshoPlumbat.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnNdryshoPlumbat.ButtonText = "Ndrysho Plumbat";
            this.btnNdryshoPlumbat.CausesValidation = false;
            this.btnNdryshoPlumbat.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btnNdryshoPlumbat.ErrorImageLeft")));
            this.btnNdryshoPlumbat.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btnNdryshoPlumbat.ErrorImageRight")));
            this.btnNdryshoPlumbat.FocusBackground = System.Drawing.Color.Empty;
            this.btnNdryshoPlumbat.FocusFontColor = System.Drawing.Color.Empty;
            this.btnNdryshoPlumbat.ForeColors = System.Drawing.Color.White;
            this.btnNdryshoPlumbat.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(0)))), ((int)(((byte)(42)))));
            this.btnNdryshoPlumbat.HoverFontColor = System.Drawing.Color.Lavender;
            this.btnNdryshoPlumbat.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btnNdryshoPlumbat.ImageLeft")));
            this.btnNdryshoPlumbat.ImageRight = null;
            this.btnNdryshoPlumbat.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btnNdryshoPlumbat.Location = new System.Drawing.Point(230, 323);
            this.btnNdryshoPlumbat.Name = "btnNdryshoPlumbat";
            this.btnNdryshoPlumbat.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btnNdryshoPlumbat.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btnNdryshoPlumbat.RightPictureColor = System.Drawing.Color.Transparent;
            this.btnNdryshoPlumbat.Size = new System.Drawing.Size(254, 43);
            this.btnNdryshoPlumbat.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btnNdryshoPlumbat.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btnNdryshoPlumbat.TabIndex = 45;
            this.btnNdryshoPlumbat.Click += new System.EventHandler(this.btnNdryshoPlumbat_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(185, 234);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(185, 175);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 43;
            this.pictureBox2.TabStop = false;
            // 
            // txtSasia
            // 
            this.txtSasia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtSasia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSasia.ForeColor = System.Drawing.Color.White;
            this.txtSasia.Location = new System.Drawing.Point(229, 233);
            this.txtSasia.Multiline = true;
            this.txtSasia.Name = "txtSasia";
            this.txtSasia.Size = new System.Drawing.Size(255, 32);
            this.txtSasia.TabIndex = 42;
            this.txtSasia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtKalibri
            // 
            this.txtKalibri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.txtKalibri.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKalibri.ForeColor = System.Drawing.Color.White;
            this.txtKalibri.Location = new System.Drawing.Point(229, 174);
            this.txtKalibri.Multiline = true;
            this.txtKalibri.Name = "txtKalibri";
            this.txtKalibri.Size = new System.Drawing.Size(255, 32);
            this.txtKalibri.TabIndex = 41;
            this.txtKalibri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(249, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 24);
            this.label1.TabIndex = 21;
            this.label1.Text = "Regjistrimi i Plumbave";
            // 
            // btnRegjistroPlumbat
            // 
            this.btnRegjistroPlumbat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroPlumbat.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(0)))), ((int)(((byte)(47)))));
            this.btnRegjistroPlumbat.ButtonText = "Regjistro Plumbat";
            this.btnRegjistroPlumbat.CausesValidation = false;
            this.btnRegjistroPlumbat.ErrorImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroPlumbat.ErrorImageLeft")));
            this.btnRegjistroPlumbat.ErrorImageRight = ((System.Drawing.Image)(resources.GetObject("btnRegjistroPlumbat.ErrorImageRight")));
            this.btnRegjistroPlumbat.FocusBackground = System.Drawing.Color.Empty;
            this.btnRegjistroPlumbat.FocusFontColor = System.Drawing.Color.Empty;
            this.btnRegjistroPlumbat.ForeColors = System.Drawing.Color.White;
            this.btnRegjistroPlumbat.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(0)))), ((int)(((byte)(42)))));
            this.btnRegjistroPlumbat.HoverFontColor = System.Drawing.Color.Lavender;
            this.btnRegjistroPlumbat.ImageLeft = ((System.Drawing.Image)(resources.GetObject("btnRegjistroPlumbat.ImageLeft")));
            this.btnRegjistroPlumbat.ImageRight = null;
            this.btnRegjistroPlumbat.LeftPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroPlumbat.Location = new System.Drawing.Point(230, 323);
            this.btnRegjistroPlumbat.Name = "btnRegjistroPlumbat";
            this.btnRegjistroPlumbat.PaddingLeftPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroPlumbat.PaddingRightPicture = new System.Windows.Forms.Padding(0);
            this.btnRegjistroPlumbat.RightPictureColor = System.Drawing.Color.Transparent;
            this.btnRegjistroPlumbat.Size = new System.Drawing.Size(254, 43);
            this.btnRegjistroPlumbat.SizeModeLeft = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btnRegjistroPlumbat.SizeModeRight = System.Windows.Forms.PictureBoxSizeMode.Normal;
            this.btnRegjistroPlumbat.TabIndex = 20;
            this.btnRegjistroPlumbat.Click += new System.EventHandler(this.btnRegjistroArmen_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // frmRegjistrimiPlumbave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 472);
            this.Controls.Add(this.jGradientPanel1);
            this.MaximumSize = new System.Drawing.Size(712, 511);
            this.MinimumSize = new System.Drawing.Size(712, 511);
            this.Name = "frmRegjistrimiPlumbave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmRegjistrimiPlumbave";
            this.Load += new System.EventHandler(this.frmRegjistrimiPlumbave_Load);
            this.jGradientPanel1.ResumeLayout(false);
            this.jGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private FlatButton.JFlatButton btnRegjistroPlumbat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private JGradient_Panel.JGradientPanel jGradientPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtSasia;
        private System.Windows.Forms.TextBox txtKalibri;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private FlatButton.JFlatButton btnNdryshoPlumbat;
		private System.Windows.Forms.Label lblNdryshimi;
	}
}